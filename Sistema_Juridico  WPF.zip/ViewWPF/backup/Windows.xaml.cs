﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Syncfusion.UI.Xaml.Schedule;
using ViewWPF.Configuracao;
using ViewWPF.Lancamentos;

namespace ViewWPF
{
    /// <summary>
    /// Lógica interna para Windows.xaml
    /// </summary>
    public partial class Windows : Window
    {
        public Windows()
        {
            InitializeComponent();
            System.Windows.Threading.DispatcherTimer dispatcherTimer = new System.Windows.Threading.DispatcherTimer();
            dispatcherTimer.Tick += new EventHandler(dispatcherTimer_Tick);
            dispatcherTimer.Interval = new TimeSpan(0, 0, 1);
            dispatcherTimer.Start();

        }

        private void dispatcherTimer_Tick(object sender, EventArgs e)
        {
            datatool.Text = DateTime.Now.ToLongDateString();
            horatoll.Text = DateTime.Now.ToLongTimeString();
        }

        private void PackIcon_MouseDown(object sender, MouseButtonEventArgs e)
        {
            Application.Current.Shutdown();
        }

        private void PackIcon_MouseDown_1(object sender, MouseButtonEventArgs e)
        {
            this.WindowState = WindowState.Minimized;
        }

        private void Grid_MouseDown(object sender, MouseButtonEventArgs e)
        {
            WConfiguracao newconfiguracao = new WConfiguracao();

            newconfiguracao.ShowDialog();

        }

        private void Grid_MouseDown_NovoCliente(object sender, MouseButtonEventArgs e)
        {
            WCadastroCliente NovoCliente = new WCadastroCliente();

            NovoCliente.ShowDialog();
        }

        private void Grid_MouseDown_SelecionaCliente(object sender, MouseButtonEventArgs e)
        {
            WSelecionaCliente SelecionaCliente = new WSelecionaCliente("");

            SelecionaCliente.ShowDialog();

        }

        private void Grid_MouseDown_NovoProcesso(object sender, MouseButtonEventArgs e)
        {
            WNovoProcesso novoprocesso = new WNovoProcesso();
            novoprocesso.Show();
        }

        private void Grid_MouseDown_SelecionaProcesso(object sender, MouseButtonEventArgs e)
        {
            try
            {
                WSelecionaProcesso SelecionaProcesso = new WSelecionaProcesso();

                SelecionaProcesso.ShowDialog();
            }
            catch (Exception er)
            {
                MessageBox.Show(er.Message);
            }
        }

        void Schedule_ScheduleTypeChanging(object sender, ScheduleTypeChangingEventArgs e)
        {
            if (Month.IsChecked == true && Schedule.ScheduleType == ScheduleType.Day)
            {
                Day.Focus();
                Day.IsChecked = true;
                Month.IsChecked = false;
            }
        }

        private void Btn_ScheduleType_Click(object sender, RoutedEventArgs e)
        {
            switch ((sender as RadioButton).Name)
            {
                case "Day":
                {
                    Schedule.ScheduleType = ScheduleType.Day;
                    break;
                }
                case "Week":
                {
                    Schedule.ScheduleType = ScheduleType.Week;
                    break;
                }
                case "WorkWeek":
                {
                    Schedule.ScheduleType = ScheduleType.WorkWeek;
                    break;
                }
                case "Month":
                {
                    Schedule.ScheduleType = ScheduleType.Month;
                    break;
                }
                case "TimeLine":
                {
                    Schedule.ScheduleType = ScheduleType.TimeLine;
                    break;
                }
            }
        }
    }
}
