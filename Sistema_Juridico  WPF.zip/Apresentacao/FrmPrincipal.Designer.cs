﻿namespace Apresentacao
{
    partial class FrmPrincipal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.cadastrosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.clientesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dadosAdicionaisClientesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.conjugueToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cívilFamiliaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.penalToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.previdenciarioToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.trabalhistaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.funcionarioToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.processosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.incluirNovoProcessoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.incluirAndamentoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.relatóriosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.configuraçãoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cadastroCargosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sairToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripLabel1 = new System.Windows.Forms.ToolStripLabel();
            this.ToolStripLabelData = new System.Windows.Forms.ToolStripLabel();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.ToolStripLabelHora = new System.Windows.Forms.ToolStripLabel();
            this.TimerDataHora = new System.Windows.Forms.Timer(this.components);
            this.Button8 = new System.Windows.Forms.Button();
            this.Button7 = new System.Windows.Forms.Button();
            this.Button6 = new System.Windows.Forms.Button();
            this.Button5 = new System.Windows.Forms.Button();
            this.Button4 = new System.Windows.Forms.Button();
            this.Button3 = new System.Windows.Forms.Button();
            this.Button2 = new System.Windows.Forms.Button();
            this.Button1 = new System.Windows.Forms.Button();
            this.Label4 = new System.Windows.Forms.Label();
            this.Panel2 = new System.Windows.Forms.Panel();
            this.MonthCalendar1 = new System.Windows.Forms.MonthCalendar();
            this.TabPage1 = new System.Windows.Forms.TabPage();
            this.Panel3 = new System.Windows.Forms.Panel();
            this.Button14 = new System.Windows.Forms.Button();
            this.Button13 = new System.Windows.Forms.Button();
            this.Button12 = new System.Windows.Forms.Button();
            this.Button11 = new System.Windows.Forms.Button();
            this.Button10 = new System.Windows.Forms.Button();
            this.Button9 = new System.Windows.Forms.Button();
            this.Label5 = new System.Windows.Forms.Label();
            this.TabControl1 = new System.Windows.Forms.TabControl();
            this.TabPage2 = new System.Windows.Forms.TabPage();
            this.MonthCalendar2 = new System.Windows.Forms.MonthCalendar();
            this.menuStrip1.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.Panel2.SuspendLayout();
            this.Panel3.SuspendLayout();
            this.TabControl1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cadastrosToolStripMenuItem,
            this.processosToolStripMenuItem,
            this.relatóriosToolStripMenuItem,
            this.configuraçãoToolStripMenuItem,
            this.sairToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1008, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // cadastrosToolStripMenuItem
            // 
            this.cadastrosToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.clientesToolStripMenuItem,
            this.dadosAdicionaisClientesToolStripMenuItem,
            this.funcionarioToolStripMenuItem});
            this.cadastrosToolStripMenuItem.Name = "cadastrosToolStripMenuItem";
            this.cadastrosToolStripMenuItem.Size = new System.Drawing.Size(71, 20);
            this.cadastrosToolStripMenuItem.Text = "Cadastros";
            // 
            // clientesToolStripMenuItem
            // 
            this.clientesToolStripMenuItem.Name = "clientesToolStripMenuItem";
            this.clientesToolStripMenuItem.Size = new System.Drawing.Size(210, 22);
            this.clientesToolStripMenuItem.Text = "Clientes";
            this.clientesToolStripMenuItem.Click += new System.EventHandler(this.clientesToolStripMenuItem_Click);
            // 
            // dadosAdicionaisClientesToolStripMenuItem
            // 
            this.dadosAdicionaisClientesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.conjugueToolStripMenuItem,
            this.cívilFamiliaToolStripMenuItem,
            this.penalToolStripMenuItem,
            this.previdenciarioToolStripMenuItem,
            this.trabalhistaToolStripMenuItem});
            this.dadosAdicionaisClientesToolStripMenuItem.Name = "dadosAdicionaisClientesToolStripMenuItem";
            this.dadosAdicionaisClientesToolStripMenuItem.Size = new System.Drawing.Size(210, 22);
            this.dadosAdicionaisClientesToolStripMenuItem.Text = "Dados Adicionais Clientes";
            // 
            // conjugueToolStripMenuItem
            // 
            this.conjugueToolStripMenuItem.Name = "conjugueToolStripMenuItem";
            this.conjugueToolStripMenuItem.Size = new System.Drawing.Size(149, 22);
            this.conjugueToolStripMenuItem.Text = "Conjugue";
            // 
            // cívilFamiliaToolStripMenuItem
            // 
            this.cívilFamiliaToolStripMenuItem.Name = "cívilFamiliaToolStripMenuItem";
            this.cívilFamiliaToolStripMenuItem.Size = new System.Drawing.Size(149, 22);
            this.cívilFamiliaToolStripMenuItem.Text = "Cívil / Familia";
            // 
            // penalToolStripMenuItem
            // 
            this.penalToolStripMenuItem.Name = "penalToolStripMenuItem";
            this.penalToolStripMenuItem.Size = new System.Drawing.Size(149, 22);
            this.penalToolStripMenuItem.Text = "Penal";
            // 
            // previdenciarioToolStripMenuItem
            // 
            this.previdenciarioToolStripMenuItem.Name = "previdenciarioToolStripMenuItem";
            this.previdenciarioToolStripMenuItem.Size = new System.Drawing.Size(149, 22);
            this.previdenciarioToolStripMenuItem.Text = "Previdenciario";
            // 
            // trabalhistaToolStripMenuItem
            // 
            this.trabalhistaToolStripMenuItem.Name = "trabalhistaToolStripMenuItem";
            this.trabalhistaToolStripMenuItem.Size = new System.Drawing.Size(149, 22);
            this.trabalhistaToolStripMenuItem.Text = "Trabalhista";
            // 
            // funcionarioToolStripMenuItem
            // 
            this.funcionarioToolStripMenuItem.Name = "funcionarioToolStripMenuItem";
            this.funcionarioToolStripMenuItem.Size = new System.Drawing.Size(210, 22);
            this.funcionarioToolStripMenuItem.Text = "Funcionário";
            this.funcionarioToolStripMenuItem.Click += new System.EventHandler(this.funcionarioToolStripMenuItem_Click);
            // 
            // processosToolStripMenuItem
            // 
            this.processosToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.incluirNovoProcessoToolStripMenuItem,
            this.incluirAndamentoToolStripMenuItem});
            this.processosToolStripMenuItem.Name = "processosToolStripMenuItem";
            this.processosToolStripMenuItem.Size = new System.Drawing.Size(71, 20);
            this.processosToolStripMenuItem.Text = "Processos";
            // 
            // incluirNovoProcessoToolStripMenuItem
            // 
            this.incluirNovoProcessoToolStripMenuItem.Name = "incluirNovoProcessoToolStripMenuItem";
            this.incluirNovoProcessoToolStripMenuItem.Size = new System.Drawing.Size(187, 22);
            this.incluirNovoProcessoToolStripMenuItem.Text = "Incluir novo Processo";
            this.incluirNovoProcessoToolStripMenuItem.Click += new System.EventHandler(this.incluirNovoProcessoToolStripMenuItem_Click);
            // 
            // incluirAndamentoToolStripMenuItem
            // 
            this.incluirAndamentoToolStripMenuItem.Name = "incluirAndamentoToolStripMenuItem";
            this.incluirAndamentoToolStripMenuItem.Size = new System.Drawing.Size(187, 22);
            this.incluirAndamentoToolStripMenuItem.Text = "Incluir Andamento";
            // 
            // relatóriosToolStripMenuItem
            // 
            this.relatóriosToolStripMenuItem.Name = "relatóriosToolStripMenuItem";
            this.relatóriosToolStripMenuItem.Size = new System.Drawing.Size(71, 20);
            this.relatóriosToolStripMenuItem.Text = "Relatórios";
            // 
            // configuraçãoToolStripMenuItem
            // 
            this.configuraçãoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cadastroCargosToolStripMenuItem});
            this.configuraçãoToolStripMenuItem.Name = "configuraçãoToolStripMenuItem";
            this.configuraçãoToolStripMenuItem.Size = new System.Drawing.Size(91, 20);
            this.configuraçãoToolStripMenuItem.Text = "Configuração";
            // 
            // cadastroCargosToolStripMenuItem
            // 
            this.cadastroCargosToolStripMenuItem.Name = "cadastroCargosToolStripMenuItem";
            this.cadastroCargosToolStripMenuItem.Size = new System.Drawing.Size(161, 22);
            this.cadastroCargosToolStripMenuItem.Text = "Cadastro Cargos";
            this.cadastroCargosToolStripMenuItem.Click += new System.EventHandler(this.cadastroCargosToolStripMenuItem_Click);
            // 
            // sairToolStripMenuItem
            // 
            this.sairToolStripMenuItem.Name = "sairToolStripMenuItem";
            this.sairToolStripMenuItem.Size = new System.Drawing.Size(38, 20);
            this.sairToolStripMenuItem.Text = "Sair";
            this.sairToolStripMenuItem.Click += new System.EventHandler(this.sairToolStripMenuItem_Click);
            // 
            // toolStrip1
            // 
            this.toolStrip1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripLabel1,
            this.ToolStripLabelData,
            this.toolStripSeparator1,
            this.ToolStripLabelHora});
            this.toolStrip1.Location = new System.Drawing.Point(0, 586);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(1008, 25);
            this.toolStrip1.TabIndex = 1;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolStripLabel1
            // 
            this.toolStripLabel1.Name = "toolStripLabel1";
            this.toolStripLabel1.Size = new System.Drawing.Size(50, 22);
            this.toolStripLabel1.Text = "Usuário:";
            // 
            // ToolStripLabelData
            // 
            this.ToolStripLabelData.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.ToolStripLabelData.Name = "ToolStripLabelData";
            this.ToolStripLabelData.Size = new System.Drawing.Size(31, 22);
            this.ToolStripLabelData.Text = "Data";
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // ToolStripLabelHora
            // 
            this.ToolStripLabelHora.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.ToolStripLabelHora.Name = "ToolStripLabelHora";
            this.ToolStripLabelHora.Size = new System.Drawing.Size(33, 22);
            this.ToolStripLabelHora.Text = "Hora";
            // 
            // TimerDataHora
            // 
            this.TimerDataHora.Enabled = true;
            this.TimerDataHora.Tick += new System.EventHandler(this.TimerDataHora_Tick);
            // 
            // Button8
            // 
            this.Button8.Location = new System.Drawing.Point(828, 15);
            this.Button8.Name = "Button8";
            this.Button8.Size = new System.Drawing.Size(90, 38);
            this.Button8.TabIndex = 7;
            this.Button8.Text = "Button8";
            this.Button8.UseVisualStyleBackColor = true;
            // 
            // Button7
            // 
            this.Button7.Location = new System.Drawing.Point(714, 15);
            this.Button7.Name = "Button7";
            this.Button7.Size = new System.Drawing.Size(90, 38);
            this.Button7.TabIndex = 6;
            this.Button7.Text = "Button7";
            this.Button7.UseVisualStyleBackColor = true;
            // 
            // Button6
            // 
            this.Button6.Location = new System.Drawing.Point(600, 15);
            this.Button6.Name = "Button6";
            this.Button6.Size = new System.Drawing.Size(90, 38);
            this.Button6.TabIndex = 5;
            this.Button6.Text = "Button6";
            this.Button6.UseVisualStyleBackColor = true;
            // 
            // Button5
            // 
            this.Button5.Location = new System.Drawing.Point(486, 15);
            this.Button5.Name = "Button5";
            this.Button5.Size = new System.Drawing.Size(90, 38);
            this.Button5.TabIndex = 4;
            this.Button5.Text = "Button5";
            this.Button5.UseVisualStyleBackColor = true;
            // 
            // Button4
            // 
            this.Button4.Location = new System.Drawing.Point(372, 15);
            this.Button4.Name = "Button4";
            this.Button4.Size = new System.Drawing.Size(90, 38);
            this.Button4.TabIndex = 3;
            this.Button4.Text = "Button4";
            this.Button4.UseVisualStyleBackColor = true;
            // 
            // Button3
            // 
            this.Button3.Location = new System.Drawing.Point(258, 15);
            this.Button3.Name = "Button3";
            this.Button3.Size = new System.Drawing.Size(90, 38);
            this.Button3.TabIndex = 2;
            this.Button3.Text = "Despesas Processuais";
            this.Button3.UseVisualStyleBackColor = true;
            // 
            // Button2
            // 
            this.Button2.Location = new System.Drawing.Point(144, 15);
            this.Button2.Name = "Button2";
            this.Button2.Size = new System.Drawing.Size(90, 38);
            this.Button2.TabIndex = 1;
            this.Button2.Text = "Buscar Processo";
            this.Button2.UseVisualStyleBackColor = true;
            // 
            // Button1
            // 
            this.Button1.Location = new System.Drawing.Point(30, 15);
            this.Button1.Name = "Button1";
            this.Button1.Size = new System.Drawing.Size(90, 38);
            this.Button1.TabIndex = 0;
            this.Button1.Text = "Incluir Andamento";
            this.Button1.UseVisualStyleBackColor = true;
            // 
            // Label4
            // 
            this.Label4.AutoSize = true;
            this.Label4.Location = new System.Drawing.Point(88, 118);
            this.Label4.Name = "Label4";
            this.Label4.Size = new System.Drawing.Size(92, 13);
            this.Label4.TabIndex = 13;
            this.Label4.Text = "Agenda Reuniões";
            // 
            // Panel2
            // 
            this.Panel2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.Panel2.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.Panel2.Controls.Add(this.Button8);
            this.Panel2.Controls.Add(this.Button7);
            this.Panel2.Controls.Add(this.Button6);
            this.Panel2.Controls.Add(this.Button5);
            this.Panel2.Controls.Add(this.Button4);
            this.Panel2.Controls.Add(this.Button3);
            this.Panel2.Controls.Add(this.Button2);
            this.Panel2.Controls.Add(this.Button1);
            this.Panel2.Location = new System.Drawing.Point(1, 23);
            this.Panel2.Name = "Panel2";
            this.Panel2.Size = new System.Drawing.Size(1007, 67);
            this.Panel2.TabIndex = 11;
            // 
            // MonthCalendar1
            // 
            this.MonthCalendar1.Location = new System.Drawing.Point(18, 140);
            this.MonthCalendar1.Name = "MonthCalendar1";
            this.MonthCalendar1.TabIndex = 9;
            this.MonthCalendar1.DateSelected += new System.Windows.Forms.DateRangeEventHandler(this.MonthCalendar1_DateSelected);
            // 
            // TabPage1
            // 
            this.TabPage1.Location = new System.Drawing.Point(4, 22);
            this.TabPage1.Name = "TabPage1";
            this.TabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.TabPage1.Size = new System.Drawing.Size(687, 378);
            this.TabPage1.TabIndex = 0;
            this.TabPage1.Text = "Agenda Reuniões";
            this.TabPage1.UseVisualStyleBackColor = true;
            // 
            // Panel3
            // 
            this.Panel3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.Panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.Panel3.Controls.Add(this.Button14);
            this.Panel3.Controls.Add(this.Button13);
            this.Panel3.Controls.Add(this.Button12);
            this.Panel3.Controls.Add(this.Button11);
            this.Panel3.Controls.Add(this.Button10);
            this.Panel3.Controls.Add(this.Button9);
            this.Panel3.Location = new System.Drawing.Point(288, 529);
            this.Panel3.Name = "Panel3";
            this.Panel3.Size = new System.Drawing.Size(689, 40);
            this.Panel3.TabIndex = 15;
            // 
            // Button14
            // 
            this.Button14.Location = new System.Drawing.Point(801, 8);
            this.Button14.Name = "Button14";
            this.Button14.Size = new System.Drawing.Size(75, 23);
            this.Button14.TabIndex = 5;
            this.Button14.Text = "Button14";
            this.Button14.UseVisualStyleBackColor = true;
            // 
            // Button13
            // 
            this.Button13.Location = new System.Drawing.Point(699, 8);
            this.Button13.Name = "Button13";
            this.Button13.Size = new System.Drawing.Size(75, 23);
            this.Button13.TabIndex = 4;
            this.Button13.Text = "Button13";
            this.Button13.UseVisualStyleBackColor = true;
            // 
            // Button12
            // 
            this.Button12.Location = new System.Drawing.Point(598, 8);
            this.Button12.Name = "Button12";
            this.Button12.Size = new System.Drawing.Size(75, 23);
            this.Button12.TabIndex = 3;
            this.Button12.Text = "Button12";
            this.Button12.UseVisualStyleBackColor = true;
            // 
            // Button11
            // 
            this.Button11.Location = new System.Drawing.Point(491, 8);
            this.Button11.Name = "Button11";
            this.Button11.Size = new System.Drawing.Size(75, 23);
            this.Button11.TabIndex = 2;
            this.Button11.Text = "Button11";
            this.Button11.UseVisualStyleBackColor = true;
            // 
            // Button10
            // 
            this.Button10.Location = new System.Drawing.Point(384, 8);
            this.Button10.Name = "Button10";
            this.Button10.Size = new System.Drawing.Size(75, 23);
            this.Button10.TabIndex = 1;
            this.Button10.Text = "Button10";
            this.Button10.UseVisualStyleBackColor = true;
            // 
            // Button9
            // 
            this.Button9.Location = new System.Drawing.Point(277, 8);
            this.Button9.Name = "Button9";
            this.Button9.Size = new System.Drawing.Size(75, 23);
            this.Button9.TabIndex = 0;
            this.Button9.Text = "Button9";
            this.Button9.UseVisualStyleBackColor = true;
            this.Button9.Click += new System.EventHandler(this.Button9_Click);
            // 
            // Label5
            // 
            this.Label5.AutoSize = true;
            this.Label5.Location = new System.Drawing.Point(88, 338);
            this.Label5.Name = "Label5";
            this.Label5.Size = new System.Drawing.Size(79, 13);
            this.Label5.TabIndex = 14;
            this.Label5.Text = "Agenda Prazos";
            // 
            // TabControl1
            // 
            this.TabControl1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.TabControl1.Controls.Add(this.TabPage1);
            this.TabControl1.Controls.Add(this.TabPage2);
            this.TabControl1.Location = new System.Drawing.Point(286, 118);
            this.TabControl1.Name = "TabControl1";
            this.TabControl1.SelectedIndex = 0;
            this.TabControl1.Size = new System.Drawing.Size(695, 404);
            this.TabControl1.TabIndex = 12;
            // 
            // TabPage2
            // 
            this.TabPage2.Location = new System.Drawing.Point(4, 22);
            this.TabPage2.Name = "TabPage2";
            this.TabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.TabPage2.Size = new System.Drawing.Size(687, 378);
            this.TabPage2.TabIndex = 1;
            this.TabPage2.Text = "Agenda Prazos";
            this.TabPage2.UseVisualStyleBackColor = true;
            // 
            // MonthCalendar2
            // 
            this.MonthCalendar2.Location = new System.Drawing.Point(18, 360);
            this.MonthCalendar2.Name = "MonthCalendar2";
            this.MonthCalendar2.TabIndex = 10;
            this.MonthCalendar2.DateSelected += new System.Windows.Forms.DateRangeEventHandler(this.MonthCalendar2_DateSelected);
            // 
            // FrmPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1008, 611);
            this.Controls.Add(this.Label4);
            this.Controls.Add(this.Panel2);
            this.Controls.Add(this.MonthCalendar1);
            this.Controls.Add(this.Panel3);
            this.Controls.Add(this.Label5);
            this.Controls.Add(this.TabControl1);
            this.Controls.Add(this.MonthCalendar2);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MainMenuStrip = this.menuStrip1;
            this.MaximizeBox = false;
            this.Name = "FrmPrincipal";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Sistema Juridico";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FrmPrincipal_FormClosing);
            this.Load += new System.EventHandler(this.FrmPrincipal_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.Panel2.ResumeLayout(false);
            this.Panel3.ResumeLayout(false);
            this.TabControl1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem cadastrosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem processosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem relatóriosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem configuraçãoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sairToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem clientesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem incluirNovoProcessoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem incluirAndamentoToolStripMenuItem;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripLabel toolStripLabel1;
        private System.Windows.Forms.ToolStripLabel ToolStripLabelData;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripLabel ToolStripLabelHora;
        private System.Windows.Forms.Timer TimerDataHora;
        internal System.Windows.Forms.Button Button8;
        internal System.Windows.Forms.Button Button7;
        internal System.Windows.Forms.Button Button6;
        internal System.Windows.Forms.Button Button5;
        internal System.Windows.Forms.Button Button4;
        internal System.Windows.Forms.Button Button3;
        internal System.Windows.Forms.Button Button2;
        internal System.Windows.Forms.Button Button1;
        internal System.Windows.Forms.Label Label4;
        internal System.Windows.Forms.Panel Panel2;
        internal System.Windows.Forms.MonthCalendar MonthCalendar1;
        internal System.Windows.Forms.TabPage TabPage1;
        internal System.Windows.Forms.Panel Panel3;
        internal System.Windows.Forms.Button Button14;
        internal System.Windows.Forms.Button Button13;
        internal System.Windows.Forms.Button Button12;
        internal System.Windows.Forms.Button Button11;
        internal System.Windows.Forms.Button Button10;
        internal System.Windows.Forms.Button Button9;
        internal System.Windows.Forms.Label Label5;
        internal System.Windows.Forms.TabControl TabControl1;
        internal System.Windows.Forms.TabPage TabPage2;
        internal System.Windows.Forms.MonthCalendar MonthCalendar2;
        private System.Windows.Forms.ToolStripMenuItem funcionarioToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cadastroCargosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dadosAdicionaisClientesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem conjugueToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cívilFamiliaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem penalToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem previdenciarioToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem trabalhistaToolStripMenuItem;
    }
}

