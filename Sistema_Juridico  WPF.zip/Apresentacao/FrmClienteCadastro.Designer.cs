﻿namespace Apresentacao
{
    partial class FrmClienteCadastro
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.TabPage9 = new System.Windows.Forms.TabPage();
            this.TextBox44 = new System.Windows.Forms.TextBox();
            this.Label60 = new System.Windows.Forms.Label();
            this.TextBox43 = new System.Windows.Forms.TextBox();
            this.Label59 = new System.Windows.Forms.Label();
            this.TextBox42 = new System.Windows.Forms.TextBox();
            this.Label58 = new System.Windows.Forms.Label();
            this.TextBox41 = new System.Windows.Forms.TextBox();
            this.Label57 = new System.Windows.Forms.Label();
            this.TextBox40 = new System.Windows.Forms.TextBox();
            this.Label56 = new System.Windows.Forms.Label();
            this.TextBox39 = new System.Windows.Forms.TextBox();
            this.Label55 = new System.Windows.Forms.Label();
            this.TextBox38 = new System.Windows.Forms.TextBox();
            this.Label54 = new System.Windows.Forms.Label();
            this.TextBox37 = new System.Windows.Forms.TextBox();
            this.Label53 = new System.Windows.Forms.Label();
            this.TabPage10 = new System.Windows.Forms.TabPage();
            this.TabControl4 = new System.Windows.Forms.TabControl();
            this.TabPage11 = new System.Windows.Forms.TabPage();
            this.BtnCartaConcessaoMemorialCalculo = new System.Windows.Forms.Button();
            this.TxbCartaConcessaoMemorialCalculo = new System.Windows.Forms.TextBox();
            this.Label63 = new System.Windows.Forms.Label();
            this.BtnCartaIndeferimentoBeneficioRequerido = new System.Windows.Forms.Button();
            this.TxtCartaIndeferimentoBeneficioRequerido = new System.Windows.Forms.TextBox();
            this.Label62 = new System.Windows.Forms.Label();
            this.BtnGuiaRecolhimentoContribuicoesPrevidenciario = new System.Windows.Forms.Button();
            this.TxtGuiaRecolhimentoContribuicoesPrevidenciario = new System.Windows.Forms.TextBox();
            this.Label61 = new System.Windows.Forms.Label();
            this.TabPage12 = new System.Windows.Forms.TabPage();
            this.button14 = new System.Windows.Forms.Button();
            this.TextBox49 = new System.Windows.Forms.TextBox();
            this.Label68 = new System.Windows.Forms.Label();
            this.TextBox48 = new System.Windows.Forms.TextBox();
            this.Label67 = new System.Windows.Forms.Label();
            this.TextBox47 = new System.Windows.Forms.TextBox();
            this.Label66 = new System.Windows.Forms.Label();
            this.TextBox46 = new System.Windows.Forms.TextBox();
            this.Label65 = new System.Windows.Forms.Label();
            this.TextBox45 = new System.Windows.Forms.TextBox();
            this.Label64 = new System.Windows.Forms.Label();
            this.Button8 = new System.Windows.Forms.Button();
            this.RadioButton2 = new System.Windows.Forms.RadioButton();
            this.RadioButton1 = new System.Windows.Forms.RadioButton();
            this.Label32 = new System.Windows.Forms.Label();
            this.Panel2 = new System.Windows.Forms.Panel();
            this.ComboBox3 = new System.Windows.Forms.ComboBox();
            this.Label28 = new System.Windows.Forms.Label();
            this.TextBox33 = new System.Windows.Forms.TextBox();
            this.Label40 = new System.Windows.Forms.Label();
            this.TextBox32 = new System.Windows.Forms.TextBox();
            this.Label39 = new System.Windows.Forms.Label();
            this.TextBox31 = new System.Windows.Forms.TextBox();
            this.Label38 = new System.Windows.Forms.Label();
            this.TabPage4 = new System.Windows.Forms.TabPage();
            this.TabControl3 = new System.Windows.Forms.TabControl();
            this.TabPage8 = new System.Windows.Forms.TabPage();
            this.Button4 = new System.Windows.Forms.Button();
            this.ComboBox4 = new System.Windows.Forms.ComboBox();
            this.ofd1 = new System.Windows.Forms.OpenFileDialog();
            this.Button7 = new System.Windows.Forms.Button();
            this.BtnAntecedentesCriminais = new System.Windows.Forms.Button();
            this.TxtAntecedentesCriminais = new System.Windows.Forms.TextBox();
            this.Label81 = new System.Windows.Forms.Label();
            this.TextBox60 = new System.Windows.Forms.TextBox();
            this.TabPage13 = new System.Windows.Forms.TabPage();
            this.Label80 = new System.Windows.Forms.Label();
            this.TextBox59 = new System.Windows.Forms.TextBox();
            this.Label79 = new System.Windows.Forms.Label();
            this.TextBox58 = new System.Windows.Forms.TextBox();
            this.Label78 = new System.Windows.Forms.Label();
            this.TextBox57 = new System.Windows.Forms.TextBox();
            this.Label77 = new System.Windows.Forms.Label();
            this.TextBox56 = new System.Windows.Forms.TextBox();
            this.Label76 = new System.Windows.Forms.Label();
            this.TextBox55 = new System.Windows.Forms.TextBox();
            this.Label75 = new System.Windows.Forms.Label();
            this.TextBox54 = new System.Windows.Forms.TextBox();
            this.Label74 = new System.Windows.Forms.Label();
            this.TextBox53 = new System.Windows.Forms.TextBox();
            this.Label73 = new System.Windows.Forms.Label();
            this.TextBox52 = new System.Windows.Forms.TextBox();
            this.Label72 = new System.Windows.Forms.Label();
            this.ComboBox1 = new System.Windows.Forms.ComboBox();
            this.Label71 = new System.Windows.Forms.Label();
            this.TextBox51 = new System.Windows.Forms.TextBox();
            this.Label70 = new System.Windows.Forms.Label();
            this.TextBox50 = new System.Windows.Forms.TextBox();
            this.Label69 = new System.Windows.Forms.Label();
            this.TextBox36 = new System.Windows.Forms.TextBox();
            this.Label19 = new System.Windows.Forms.Label();
            this.TextBox19 = new System.Windows.Forms.TextBox();
            this.Label20 = new System.Windows.Forms.Label();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.Label15 = new System.Windows.Forms.Label();
            this.Label11 = new System.Windows.Forms.Label();
            this.Label13 = new System.Windows.Forms.Label();
            this.Label12 = new System.Windows.Forms.Label();
            this.Label10 = new System.Windows.Forms.Label();
            this.txtResidencia = new System.Windows.Forms.TextBox();
            this.Label17 = new System.Windows.Forms.Label();
            this.Label18 = new System.Windows.Forms.Label();
            this.Label9 = new System.Windows.Forms.Label();
            this.Label8 = new System.Windows.Forms.Label();
            this.txtDomicilio = new System.Windows.Forms.TextBox();
            this.txtNacionalidade = new System.Windows.Forms.TextBox();
            this.Label6 = new System.Windows.Forms.Label();
            this.Label16 = new System.Windows.Forms.Label();
            this.Label21 = new System.Windows.Forms.Label();
            this.TextBox21 = new System.Windows.Forms.TextBox();
            this.Label22 = new System.Windows.Forms.Label();
            this.Label7 = new System.Windows.Forms.Label();
            this.Panel1 = new System.Windows.Forms.Panel();
            this.Label43 = new System.Windows.Forms.Label();
            this.TextBox35 = new System.Windows.Forms.TextBox();
            this.Label42 = new System.Windows.Forms.Label();
            this.TextBox34 = new System.Windows.Forms.TextBox();
            this.Label41 = new System.Windows.Forms.Label();
            this.DataGridView2 = new System.Windows.Forms.DataGridView();
            this.Label5 = new System.Windows.Forms.Label();
            this.TextBox13 = new System.Windows.Forms.TextBox();
            this.TabPage2 = new System.Windows.Forms.TabPage();
            this.label31 = new System.Windows.Forms.Label();
            this.maskedTextBox6 = new System.Windows.Forms.MaskedTextBox();
            this.maskedTextBox7 = new System.Windows.Forms.MaskedTextBox();
            this.maskedTextBox8 = new System.Windows.Forms.MaskedTextBox();
            this.maskedTextBox9 = new System.Windows.Forms.MaskedTextBox();
            this.maskedTextBox10 = new System.Windows.Forms.MaskedTextBox();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.comboBox7 = new System.Windows.Forms.ComboBox();
            this.comboBox8 = new System.Windows.Forms.ComboBox();
            this.Label14 = new System.Windows.Forms.Label();
            this.TextBox22 = new System.Windows.Forms.TextBox();
            this.Label23 = new System.Windows.Forms.Label();
            this.Label24 = new System.Windows.Forms.Label();
            this.TextBox24 = new System.Windows.Forms.TextBox();
            this.Label25 = new System.Windows.Forms.Label();
            this.Label26 = new System.Windows.Forms.Label();
            this.TextBox26 = new System.Windows.Forms.TextBox();
            this.Label27 = new System.Windows.Forms.Label();
            this.txtRG = new System.Windows.Forms.TextBox();
            this.Label4 = new System.Windows.Forms.Label();
            this.Label3 = new System.Windows.Forms.Label();
            this.txtnome = new System.Windows.Forms.TextBox();
            this.Label2 = new System.Windows.Forms.Label();
            this.TabPage1 = new System.Windows.Forms.TabPage();
            this.mktCPF = new System.Windows.Forms.MaskedTextBox();
            this.mktCepResidencia = new System.Windows.Forms.MaskedTextBox();
            this.mktCepDomicilio = new System.Windows.Forms.MaskedTextBox();
            this.mktCelular = new System.Windows.Forms.MaskedTextBox();
            this.mktTelefone = new System.Windows.Forms.MaskedTextBox();
            this.dtpDataNascimento = new System.Windows.Forms.DateTimePicker();
            this.cmbEstadoCivil = new System.Windows.Forms.ComboBox();
            this.cmbSexo = new System.Windows.Forms.ComboBox();
            this.label29 = new System.Windows.Forms.Label();
            this.TabControl1 = new System.Windows.Forms.TabControl();
            this.TabPage3 = new System.Windows.Forms.TabPage();
            this.TabControl2 = new System.Windows.Forms.TabControl();
            this.TabPage5 = new System.Windows.Forms.TabPage();
            this.Button10 = new System.Windows.Forms.Button();
            this.ComboBox2 = new System.Windows.Forms.ComboBox();
            this.TabPage6 = new System.Windows.Forms.TabPage();
            this.label30 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox62 = new System.Windows.Forms.TextBox();
            this.textBox61 = new System.Windows.Forms.TextBox();
            this.Button9 = new System.Windows.Forms.Button();
            this.Button6 = new System.Windows.Forms.Button();
            this.Button5 = new System.Windows.Forms.Button();
            this.TextBox30 = new System.Windows.Forms.TextBox();
            this.Label36 = new System.Windows.Forms.Label();
            this.TextBox29 = new System.Windows.Forms.TextBox();
            this.Label35 = new System.Windows.Forms.Label();
            this.TextBox28 = new System.Windows.Forms.TextBox();
            this.Label34 = new System.Windows.Forms.Label();
            this.TextBox27 = new System.Windows.Forms.TextBox();
            this.Label33 = new System.Windows.Forms.Label();
            this.DataGridView1 = new System.Windows.Forms.DataGridView();
            this.TabPage7 = new System.Windows.Forms.TabPage();
            this.Label37 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnSalvar = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.TabPage9.SuspendLayout();
            this.TabPage10.SuspendLayout();
            this.TabControl4.SuspendLayout();
            this.TabPage11.SuspendLayout();
            this.TabPage12.SuspendLayout();
            this.Panel2.SuspendLayout();
            this.TabPage4.SuspendLayout();
            this.TabControl3.SuspendLayout();
            this.TabPage8.SuspendLayout();
            this.TabPage13.SuspendLayout();
            this.Panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DataGridView2)).BeginInit();
            this.TabPage2.SuspendLayout();
            this.TabPage1.SuspendLayout();
            this.TabControl1.SuspendLayout();
            this.TabPage3.SuspendLayout();
            this.TabControl2.SuspendLayout();
            this.TabPage5.SuspendLayout();
            this.TabPage6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DataGridView1)).BeginInit();
            this.TabPage7.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // TabPage9
            // 
            this.TabPage9.Controls.Add(this.TextBox44);
            this.TabPage9.Controls.Add(this.Label60);
            this.TabPage9.Controls.Add(this.TextBox43);
            this.TabPage9.Controls.Add(this.Label59);
            this.TabPage9.Controls.Add(this.TextBox42);
            this.TabPage9.Controls.Add(this.Label58);
            this.TabPage9.Controls.Add(this.TextBox41);
            this.TabPage9.Controls.Add(this.Label57);
            this.TabPage9.Controls.Add(this.TextBox40);
            this.TabPage9.Controls.Add(this.Label56);
            this.TabPage9.Controls.Add(this.TextBox39);
            this.TabPage9.Controls.Add(this.Label55);
            this.TabPage9.Controls.Add(this.TextBox38);
            this.TabPage9.Controls.Add(this.Label54);
            this.TabPage9.Controls.Add(this.TextBox37);
            this.TabPage9.Controls.Add(this.Label53);
            this.TabPage9.Location = new System.Drawing.Point(4, 22);
            this.TabPage9.Name = "TabPage9";
            this.TabPage9.Padding = new System.Windows.Forms.Padding(3);
            this.TabPage9.Size = new System.Drawing.Size(599, 269);
            this.TabPage9.TabIndex = 1;
            this.TabPage9.Text = "Dados Adicionais";
            this.TabPage9.UseVisualStyleBackColor = true;
            // 
            // TextBox44
            // 
            this.TextBox44.Location = new System.Drawing.Point(9, 180);
            this.TextBox44.Multiline = true;
            this.TextBox44.Name = "TextBox44";
            this.TextBox44.Size = new System.Drawing.Size(584, 43);
            this.TextBox44.TabIndex = 15;
            // 
            // Label60
            // 
            this.Label60.AutoSize = true;
            this.Label60.Location = new System.Drawing.Point(6, 164);
            this.Label60.Name = "Label60";
            this.Label60.Size = new System.Drawing.Size(32, 13);
            this.Label60.TabIndex = 14;
            this.Label60.Text = "Obs.:";
            // 
            // TextBox43
            // 
            this.TextBox43.Location = new System.Drawing.Point(9, 130);
            this.TextBox43.Name = "TextBox43";
            this.TextBox43.Size = new System.Drawing.Size(584, 20);
            this.TextBox43.TabIndex = 13;
            // 
            // Label59
            // 
            this.Label59.AutoSize = true;
            this.Label59.Location = new System.Drawing.Point(6, 114);
            this.Label59.Name = "Label59";
            this.Label59.Size = new System.Drawing.Size(194, 13);
            this.Label59.TabIndex = 12;
            this.Label59.Text = "Advertências disciplinares, suspensões:";
            // 
            // TextBox42
            // 
            this.TextBox42.Location = new System.Drawing.Point(433, 81);
            this.TextBox42.Name = "TextBox42";
            this.TextBox42.Size = new System.Drawing.Size(160, 20);
            this.TextBox42.TabIndex = 11;
            // 
            // Label58
            // 
            this.Label58.AutoSize = true;
            this.Label58.Location = new System.Drawing.Point(430, 65);
            this.Label58.Name = "Label58";
            this.Label58.Size = new System.Drawing.Size(53, 13);
            this.Label58.TabIndex = 10;
            this.Label58.Text = "Licenças:";
            // 
            // TextBox41
            // 
            this.TextBox41.Location = new System.Drawing.Point(236, 81);
            this.TextBox41.Name = "TextBox41";
            this.TextBox41.Size = new System.Drawing.Size(180, 20);
            this.TextBox41.TabIndex = 9;
            // 
            // Label57
            // 
            this.Label57.AutoSize = true;
            this.Label57.Location = new System.Drawing.Point(233, 65);
            this.Label57.Name = "Label57";
            this.Label57.Size = new System.Drawing.Size(69, 13);
            this.Label57.TabIndex = 8;
            this.Label57.Text = "Aviso Prévio:";
            // 
            // TextBox40
            // 
            this.TextBox40.Location = new System.Drawing.Point(9, 81);
            this.TextBox40.Name = "TextBox40";
            this.TextBox40.Size = new System.Drawing.Size(209, 20);
            this.TextBox40.TabIndex = 7;
            // 
            // Label56
            // 
            this.Label56.AutoSize = true;
            this.Label56.Location = new System.Drawing.Point(6, 65);
            this.Label56.Name = "Label56";
            this.Label56.Size = new System.Drawing.Size(110, 13);
            this.Label56.TabIndex = 6;
            this.Label56.Text = "Seguro Desemprego: ";
            // 
            // TextBox39
            // 
            this.TextBox39.Location = new System.Drawing.Point(433, 29);
            this.TextBox39.Name = "TextBox39";
            this.TextBox39.Size = new System.Drawing.Size(160, 20);
            this.TextBox39.TabIndex = 5;
            // 
            // Label55
            // 
            this.Label55.AutoSize = true;
            this.Label55.Location = new System.Drawing.Point(430, 13);
            this.Label55.Name = "Label55";
            this.Label55.Size = new System.Drawing.Size(38, 13);
            this.Label55.TabIndex = 4;
            this.Label55.Text = "FGTS:";
            // 
            // TextBox38
            // 
            this.TextBox38.Location = new System.Drawing.Point(236, 29);
            this.TextBox38.Name = "TextBox38";
            this.TextBox38.Size = new System.Drawing.Size(180, 20);
            this.TextBox38.TabIndex = 3;
            // 
            // Label54
            // 
            this.Label54.AutoSize = true;
            this.Label54.Location = new System.Drawing.Point(233, 13);
            this.Label54.Name = "Label54";
            this.Label54.Size = new System.Drawing.Size(80, 13);
            this.Label54.TabIndex = 2;
            this.Label54.Text = "Registro CTPS:";
            // 
            // TextBox37
            // 
            this.TextBox37.Location = new System.Drawing.Point(7, 29);
            this.TextBox37.Name = "TextBox37";
            this.TextBox37.Size = new System.Drawing.Size(211, 20);
            this.TextBox37.TabIndex = 1;
            // 
            // Label53
            // 
            this.Label53.AutoSize = true;
            this.Label53.Location = new System.Drawing.Point(6, 13);
            this.Label53.Name = "Label53";
            this.Label53.Size = new System.Drawing.Size(85, 13);
            this.Label53.TabIndex = 0;
            this.Label53.Text = "Número do PIS: ";
            // 
            // TabPage10
            // 
            this.TabPage10.Controls.Add(this.TabControl4);
            this.TabPage10.Location = new System.Drawing.Point(4, 22);
            this.TabPage10.Name = "TabPage10";
            this.TabPage10.Padding = new System.Windows.Forms.Padding(3);
            this.TabPage10.Size = new System.Drawing.Size(619, 262);
            this.TabPage10.TabIndex = 4;
            this.TabPage10.Text = "Previdenciário";
            this.TabPage10.UseVisualStyleBackColor = true;
            // 
            // TabControl4
            // 
            this.TabControl4.Controls.Add(this.TabPage11);
            this.TabControl4.Controls.Add(this.TabPage12);
            this.TabControl4.Location = new System.Drawing.Point(6, 6);
            this.TabControl4.Name = "TabControl4";
            this.TabControl4.SelectedIndex = 0;
            this.TabControl4.Size = new System.Drawing.Size(607, 295);
            this.TabControl4.TabIndex = 0;
            // 
            // TabPage11
            // 
            this.TabPage11.Controls.Add(this.BtnCartaConcessaoMemorialCalculo);
            this.TabPage11.Controls.Add(this.TxbCartaConcessaoMemorialCalculo);
            this.TabPage11.Controls.Add(this.Label63);
            this.TabPage11.Controls.Add(this.BtnCartaIndeferimentoBeneficioRequerido);
            this.TabPage11.Controls.Add(this.TxtCartaIndeferimentoBeneficioRequerido);
            this.TabPage11.Controls.Add(this.Label62);
            this.TabPage11.Controls.Add(this.BtnGuiaRecolhimentoContribuicoesPrevidenciario);
            this.TabPage11.Controls.Add(this.TxtGuiaRecolhimentoContribuicoesPrevidenciario);
            this.TabPage11.Controls.Add(this.Label61);
            this.TabPage11.Location = new System.Drawing.Point(4, 22);
            this.TabPage11.Name = "TabPage11";
            this.TabPage11.Padding = new System.Windows.Forms.Padding(3);
            this.TabPage11.Size = new System.Drawing.Size(599, 269);
            this.TabPage11.TabIndex = 0;
            this.TabPage11.Text = "Anexos";
            this.TabPage11.UseVisualStyleBackColor = true;
            // 
            // BtnCartaConcessaoMemorialCalculo
            // 
            this.BtnCartaConcessaoMemorialCalculo.Location = new System.Drawing.Point(456, 91);
            this.BtnCartaConcessaoMemorialCalculo.Name = "BtnCartaConcessaoMemorialCalculo";
            this.BtnCartaConcessaoMemorialCalculo.Size = new System.Drawing.Size(75, 23);
            this.BtnCartaConcessaoMemorialCalculo.TabIndex = 30;
            this.BtnCartaConcessaoMemorialCalculo.Text = "Anexar";
            this.BtnCartaConcessaoMemorialCalculo.UseVisualStyleBackColor = true;
            // 
            // TxbCartaConcessaoMemorialCalculo
            // 
            this.TxbCartaConcessaoMemorialCalculo.Location = new System.Drawing.Point(219, 94);
            this.TxbCartaConcessaoMemorialCalculo.Name = "TxbCartaConcessaoMemorialCalculo";
            this.TxbCartaConcessaoMemorialCalculo.Size = new System.Drawing.Size(215, 20);
            this.TxbCartaConcessaoMemorialCalculo.TabIndex = 29;
            // 
            // Label63
            // 
            this.Label63.AutoSize = true;
            this.Label63.Location = new System.Drawing.Point(6, 97);
            this.Label63.Name = "Label63";
            this.Label63.Size = new System.Drawing.Size(211, 13);
            this.Label63.TabIndex = 28;
            this.Label63.Text = "Carta de Concessão e memorial de cálculo:";
            // 
            // BtnCartaIndeferimentoBeneficioRequerido
            // 
            this.BtnCartaIndeferimentoBeneficioRequerido.Location = new System.Drawing.Point(456, 55);
            this.BtnCartaIndeferimentoBeneficioRequerido.Name = "BtnCartaIndeferimentoBeneficioRequerido";
            this.BtnCartaIndeferimentoBeneficioRequerido.Size = new System.Drawing.Size(75, 23);
            this.BtnCartaIndeferimentoBeneficioRequerido.TabIndex = 27;
            this.BtnCartaIndeferimentoBeneficioRequerido.Text = "Anexar";
            this.BtnCartaIndeferimentoBeneficioRequerido.UseVisualStyleBackColor = true;
            // 
            // TxtCartaIndeferimentoBeneficioRequerido
            // 
            this.TxtCartaIndeferimentoBeneficioRequerido.Location = new System.Drawing.Point(241, 58);
            this.TxtCartaIndeferimentoBeneficioRequerido.Name = "TxtCartaIndeferimentoBeneficioRequerido";
            this.TxtCartaIndeferimentoBeneficioRequerido.Size = new System.Drawing.Size(193, 20);
            this.TxtCartaIndeferimentoBeneficioRequerido.TabIndex = 26;
            // 
            // Label62
            // 
            this.Label62.AutoSize = true;
            this.Label62.Location = new System.Drawing.Point(6, 61);
            this.Label62.Name = "Label62";
            this.Label62.Size = new System.Drawing.Size(233, 13);
            this.Label62.TabIndex = 25;
            this.Label62.Text = "Carta de Indeferimento do Benefício Requerido:";
            // 
            // BtnGuiaRecolhimentoContribuicoesPrevidenciario
            // 
            this.BtnGuiaRecolhimentoContribuicoesPrevidenciario.Location = new System.Drawing.Point(456, 19);
            this.BtnGuiaRecolhimentoContribuicoesPrevidenciario.Name = "BtnGuiaRecolhimentoContribuicoesPrevidenciario";
            this.BtnGuiaRecolhimentoContribuicoesPrevidenciario.Size = new System.Drawing.Size(75, 23);
            this.BtnGuiaRecolhimentoContribuicoesPrevidenciario.TabIndex = 24;
            this.BtnGuiaRecolhimentoContribuicoesPrevidenciario.Text = "Anexar";
            this.BtnGuiaRecolhimentoContribuicoesPrevidenciario.UseVisualStyleBackColor = true;
            // 
            // TxtGuiaRecolhimentoContribuicoesPrevidenciario
            // 
            this.TxtGuiaRecolhimentoContribuicoesPrevidenciario.Location = new System.Drawing.Point(287, 22);
            this.TxtGuiaRecolhimentoContribuicoesPrevidenciario.Name = "TxtGuiaRecolhimentoContribuicoesPrevidenciario";
            this.TxtGuiaRecolhimentoContribuicoesPrevidenciario.Size = new System.Drawing.Size(147, 20);
            this.TxtGuiaRecolhimentoContribuicoesPrevidenciario.TabIndex = 23;
            // 
            // Label61
            // 
            this.Label61.AutoSize = true;
            this.Label61.Location = new System.Drawing.Point(6, 24);
            this.Label61.Name = "Label61";
            this.Label61.Size = new System.Drawing.Size(277, 13);
            this.Label61.TabIndex = 22;
            this.Label61.Text = "Guia de Recolhimento das Contribuições Previdenciárias:";
            // 
            // TabPage12
            // 
            this.TabPage12.Controls.Add(this.button14);
            this.TabPage12.Controls.Add(this.TextBox49);
            this.TabPage12.Controls.Add(this.Label68);
            this.TabPage12.Controls.Add(this.TextBox48);
            this.TabPage12.Controls.Add(this.Label67);
            this.TabPage12.Controls.Add(this.TextBox47);
            this.TabPage12.Controls.Add(this.Label66);
            this.TabPage12.Controls.Add(this.TextBox46);
            this.TabPage12.Controls.Add(this.Label65);
            this.TabPage12.Controls.Add(this.TextBox45);
            this.TabPage12.Controls.Add(this.Label64);
            this.TabPage12.Location = new System.Drawing.Point(4, 22);
            this.TabPage12.Name = "TabPage12";
            this.TabPage12.Padding = new System.Windows.Forms.Padding(3);
            this.TabPage12.Size = new System.Drawing.Size(599, 269);
            this.TabPage12.TabIndex = 1;
            this.TabPage12.Text = "Dados Adicionais";
            this.TabPage12.UseVisualStyleBackColor = true;
            // 
            // button14
            // 
            this.button14.Location = new System.Drawing.Point(505, 233);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(75, 23);
            this.button14.TabIndex = 78;
            this.button14.Text = "Salvar";
            this.button14.UseVisualStyleBackColor = true;
            // 
            // TextBox49
            // 
            this.TextBox49.Location = new System.Drawing.Point(6, 203);
            this.TextBox49.Name = "TextBox49";
            this.TextBox49.Size = new System.Drawing.Size(571, 20);
            this.TextBox49.TabIndex = 9;
            // 
            // Label68
            // 
            this.Label68.AutoSize = true;
            this.Label68.Location = new System.Drawing.Point(6, 187);
            this.Label68.Name = "Label68";
            this.Label68.Size = new System.Drawing.Size(143, 13);
            this.Label68.TabIndex = 8;
            this.Label68.Text = "Procedimento Administrativo:";
            // 
            // TextBox48
            // 
            this.TextBox48.Location = new System.Drawing.Point(6, 164);
            this.TextBox48.Name = "TextBox48";
            this.TextBox48.Size = new System.Drawing.Size(574, 20);
            this.TextBox48.TabIndex = 7;
            // 
            // Label67
            // 
            this.Label67.AutoSize = true;
            this.Label67.Location = new System.Drawing.Point(6, 148);
            this.Label67.Name = "Label67";
            this.Label67.Size = new System.Drawing.Size(78, 13);
            this.Label67.TabIndex = 6;
            this.Label67.Text = "Aposentadoria:";
            // 
            // TextBox47
            // 
            this.TextBox47.Location = new System.Drawing.Point(6, 124);
            this.TextBox47.Name = "TextBox47";
            this.TextBox47.Size = new System.Drawing.Size(574, 20);
            this.TextBox47.TabIndex = 5;
            // 
            // Label66
            // 
            this.Label66.AutoSize = true;
            this.Label66.Location = new System.Drawing.Point(6, 108);
            this.Label66.Name = "Label66";
            this.Label66.Size = new System.Drawing.Size(61, 13);
            this.Label66.TabIndex = 4;
            this.Label66.Text = "Benefícios:";
            // 
            // TextBox46
            // 
            this.TextBox46.Location = new System.Drawing.Point(6, 83);
            this.TextBox46.Name = "TextBox46";
            this.TextBox46.Size = new System.Drawing.Size(571, 20);
            this.TextBox46.TabIndex = 3;
            // 
            // Label65
            // 
            this.Label65.AutoSize = true;
            this.Label65.Location = new System.Drawing.Point(6, 65);
            this.Label65.Name = "Label65";
            this.Label65.Size = new System.Drawing.Size(241, 13);
            this.Label65.TabIndex = 2;
            this.Label65.Text = "CNIS(Cadastro Nacional de Informações Sociais):";
            // 
            // TextBox45
            // 
            this.TextBox45.Location = new System.Drawing.Point(6, 32);
            this.TextBox45.Name = "TextBox45";
            this.TextBox45.Size = new System.Drawing.Size(572, 20);
            this.TextBox45.TabIndex = 1;
            // 
            // Label64
            // 
            this.Label64.AutoSize = true;
            this.Label64.Location = new System.Drawing.Point(6, 16);
            this.Label64.Name = "Label64";
            this.Label64.Size = new System.Drawing.Size(243, 13);
            this.Label64.TabIndex = 0;
            this.Label64.Text = "Carteira de Trabalho e Previdência Social (CTPS):";
            // 
            // Button8
            // 
            this.Button8.Location = new System.Drawing.Point(193, 179);
            this.Button8.Name = "Button8";
            this.Button8.Size = new System.Drawing.Size(75, 23);
            this.Button8.TabIndex = 10;
            this.Button8.Text = "Excluir";
            this.Button8.UseVisualStyleBackColor = true;
            // 
            // RadioButton2
            // 
            this.RadioButton2.AutoSize = true;
            this.RadioButton2.Location = new System.Drawing.Point(315, 89);
            this.RadioButton2.Name = "RadioButton2";
            this.RadioButton2.Size = new System.Drawing.Size(83, 17);
            this.RadioButton2.TabIndex = 8;
            this.RadioButton2.TabStop = true;
            this.RadioButton2.Text = "Ben Imóveis";
            this.RadioButton2.UseVisualStyleBackColor = true;
            // 
            // RadioButton1
            // 
            this.RadioButton1.AutoSize = true;
            this.RadioButton1.Location = new System.Drawing.Point(228, 89);
            this.RadioButton1.Name = "RadioButton1";
            this.RadioButton1.Size = new System.Drawing.Size(81, 17);
            this.RadioButton1.TabIndex = 7;
            this.RadioButton1.TabStop = true;
            this.RadioButton1.Text = "Ben Móveis";
            this.RadioButton1.UseVisualStyleBackColor = true;
            // 
            // Label32
            // 
            this.Label32.AutoSize = true;
            this.Label32.Location = new System.Drawing.Point(15, 21);
            this.Label32.Name = "Label32";
            this.Label32.Size = new System.Drawing.Size(83, 13);
            this.Label32.TabIndex = 32;
            this.Label32.Text = "Conta Bancária:";
            // 
            // Panel2
            // 
            this.Panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Panel2.Controls.Add(this.ComboBox3);
            this.Panel2.Controls.Add(this.Label28);
            this.Panel2.Controls.Add(this.TextBox33);
            this.Panel2.Controls.Add(this.Label40);
            this.Panel2.Controls.Add(this.TextBox32);
            this.Panel2.Controls.Add(this.Label39);
            this.Panel2.Controls.Add(this.TextBox31);
            this.Panel2.Controls.Add(this.Label38);
            this.Panel2.Location = new System.Drawing.Point(10, 29);
            this.Panel2.Name = "Panel2";
            this.Panel2.Size = new System.Drawing.Size(118, 185);
            this.Panel2.TabIndex = 31;
            // 
            // ComboBox3
            // 
            this.ComboBox3.FormattingEnabled = true;
            this.ComboBox3.Items.AddRange(new object[] {
            "Corrente",
            "Poupança"});
            this.ComboBox3.Location = new System.Drawing.Point(7, 109);
            this.ComboBox3.Name = "ComboBox3";
            this.ComboBox3.Size = new System.Drawing.Size(99, 21);
            this.ComboBox3.TabIndex = 7;
            // 
            // Label28
            // 
            this.Label28.AutoSize = true;
            this.Label28.Location = new System.Drawing.Point(7, 135);
            this.Label28.Name = "Label28";
            this.Label28.Size = new System.Drawing.Size(47, 13);
            this.Label28.TabIndex = 6;
            this.Label28.Text = "Número:";
            // 
            // TextBox33
            // 
            this.TextBox33.Location = new System.Drawing.Point(7, 151);
            this.TextBox33.Name = "TextBox33";
            this.TextBox33.Size = new System.Drawing.Size(100, 20);
            this.TextBox33.TabIndex = 5;
            // 
            // Label40
            // 
            this.Label40.AutoSize = true;
            this.Label40.Location = new System.Drawing.Point(3, 93);
            this.Label40.Name = "Label40";
            this.Label40.Size = new System.Drawing.Size(38, 13);
            this.Label40.TabIndex = 4;
            this.Label40.Text = "Conta:";
            // 
            // TextBox32
            // 
            this.TextBox32.Location = new System.Drawing.Point(6, 70);
            this.TextBox32.Name = "TextBox32";
            this.TextBox32.Size = new System.Drawing.Size(100, 20);
            this.TextBox32.TabIndex = 3;
            // 
            // Label39
            // 
            this.Label39.AutoSize = true;
            this.Label39.Location = new System.Drawing.Point(3, 49);
            this.Label39.Name = "Label39";
            this.Label39.Size = new System.Drawing.Size(49, 13);
            this.Label39.TabIndex = 2;
            this.Label39.Text = "Agencia:";
            // 
            // TextBox31
            // 
            this.TextBox31.Location = new System.Drawing.Point(6, 24);
            this.TextBox31.Name = "TextBox31";
            this.TextBox31.Size = new System.Drawing.Size(100, 20);
            this.TextBox31.TabIndex = 1;
            // 
            // Label38
            // 
            this.Label38.AutoSize = true;
            this.Label38.Location = new System.Drawing.Point(3, 8);
            this.Label38.Name = "Label38";
            this.Label38.Size = new System.Drawing.Size(41, 13);
            this.Label38.TabIndex = 0;
            this.Label38.Text = "Banco:";
            // 
            // TabPage4
            // 
            this.TabPage4.Controls.Add(this.TabControl3);
            this.TabPage4.Location = new System.Drawing.Point(4, 22);
            this.TabPage4.Name = "TabPage4";
            this.TabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.TabPage4.Size = new System.Drawing.Size(619, 262);
            this.TabPage4.TabIndex = 3;
            this.TabPage4.Text = "Trabalhista";
            this.TabPage4.UseVisualStyleBackColor = true;
            // 
            // TabControl3
            // 
            this.TabControl3.Controls.Add(this.TabPage8);
            this.TabControl3.Controls.Add(this.TabPage9);
            this.TabControl3.Location = new System.Drawing.Point(6, 6);
            this.TabControl3.Name = "TabControl3";
            this.TabControl3.SelectedIndex = 0;
            this.TabControl3.Size = new System.Drawing.Size(607, 295);
            this.TabControl3.TabIndex = 0;
            // 
            // TabPage8
            // 
            this.TabPage8.Controls.Add(this.Button4);
            this.TabPage8.Controls.Add(this.ComboBox4);
            this.TabPage8.Location = new System.Drawing.Point(4, 22);
            this.TabPage8.Name = "TabPage8";
            this.TabPage8.Padding = new System.Windows.Forms.Padding(3);
            this.TabPage8.Size = new System.Drawing.Size(599, 269);
            this.TabPage8.TabIndex = 0;
            this.TabPage8.Text = "Anexos";
            this.TabPage8.UseVisualStyleBackColor = true;
            // 
            // Button4
            // 
            this.Button4.Location = new System.Drawing.Point(420, 6);
            this.Button4.Name = "Button4";
            this.Button4.Size = new System.Drawing.Size(92, 23);
            this.Button4.TabIndex = 47;
            this.Button4.Text = "Anexar";
            this.Button4.UseVisualStyleBackColor = true;
            // 
            // ComboBox4
            // 
            this.ComboBox4.FormattingEnabled = true;
            this.ComboBox4.Items.AddRange(new object[] {
            "Contrato de Trabalho",
            "Aditivos Contratuais",
            "Comprovante Recolhimento INSS",
            "Termo de recisão de Contrato de Trabalho",
            "Atestato Médico",
            "Certidão de Nascimento dos filhos menores",
            "Comunicação de Acidente de trabalho - CAT",
            "Comprovantes de comunicação de Abandono de Emprego",
            "Recibos de Pagamentos"});
            this.ComboBox4.Location = new System.Drawing.Point(25, 6);
            this.ComboBox4.Name = "ComboBox4";
            this.ComboBox4.Size = new System.Drawing.Size(370, 21);
            this.ComboBox4.TabIndex = 46;
            // 
            // ofd1
            // 
            this.ofd1.FileName = "OpenFileDialog1";
            // 
            // Button7
            // 
            this.Button7.Location = new System.Drawing.Point(77, 179);
            this.Button7.Name = "Button7";
            this.Button7.Size = new System.Drawing.Size(75, 23);
            this.Button7.TabIndex = 9;
            this.Button7.Text = "Salvar";
            this.Button7.UseVisualStyleBackColor = true;
            // 
            // BtnAntecedentesCriminais
            // 
            this.BtnAntecedentesCriminais.Location = new System.Drawing.Point(231, 224);
            this.BtnAntecedentesCriminais.Name = "BtnAntecedentesCriminais";
            this.BtnAntecedentesCriminais.Size = new System.Drawing.Size(75, 23);
            this.BtnAntecedentesCriminais.TabIndex = 26;
            this.BtnAntecedentesCriminais.Text = "Anexar";
            this.BtnAntecedentesCriminais.UseVisualStyleBackColor = true;
            // 
            // TxtAntecedentesCriminais
            // 
            this.TxtAntecedentesCriminais.Location = new System.Drawing.Point(6, 225);
            this.TxtAntecedentesCriminais.Name = "TxtAntecedentesCriminais";
            this.TxtAntecedentesCriminais.Size = new System.Drawing.Size(216, 20);
            this.TxtAntecedentesCriminais.TabIndex = 25;
            // 
            // Label81
            // 
            this.Label81.AutoSize = true;
            this.Label81.Location = new System.Drawing.Point(6, 211);
            this.Label81.Name = "Label81";
            this.Label81.Size = new System.Drawing.Size(120, 13);
            this.Label81.TabIndex = 24;
            this.Label81.Text = "Antecedentes Criminais:";
            // 
            // TextBox60
            // 
            this.TextBox60.Location = new System.Drawing.Point(304, 184);
            this.TextBox60.Name = "TextBox60";
            this.TextBox60.Size = new System.Drawing.Size(309, 20);
            this.TextBox60.TabIndex = 23;
            // 
            // TabPage13
            // 
            this.TabPage13.Controls.Add(this.BtnAntecedentesCriminais);
            this.TabPage13.Controls.Add(this.TxtAntecedentesCriminais);
            this.TabPage13.Controls.Add(this.Label81);
            this.TabPage13.Controls.Add(this.TextBox60);
            this.TabPage13.Controls.Add(this.Label80);
            this.TabPage13.Controls.Add(this.TextBox59);
            this.TabPage13.Controls.Add(this.Label79);
            this.TabPage13.Controls.Add(this.TextBox58);
            this.TabPage13.Controls.Add(this.Label78);
            this.TabPage13.Controls.Add(this.TextBox57);
            this.TabPage13.Controls.Add(this.Label77);
            this.TabPage13.Controls.Add(this.TextBox56);
            this.TabPage13.Controls.Add(this.Label76);
            this.TabPage13.Controls.Add(this.TextBox55);
            this.TabPage13.Controls.Add(this.Label75);
            this.TabPage13.Controls.Add(this.TextBox54);
            this.TabPage13.Controls.Add(this.Label74);
            this.TabPage13.Controls.Add(this.TextBox53);
            this.TabPage13.Controls.Add(this.Label73);
            this.TabPage13.Controls.Add(this.TextBox52);
            this.TabPage13.Controls.Add(this.Label72);
            this.TabPage13.Controls.Add(this.ComboBox1);
            this.TabPage13.Controls.Add(this.Label71);
            this.TabPage13.Controls.Add(this.TextBox51);
            this.TabPage13.Controls.Add(this.Label70);
            this.TabPage13.Controls.Add(this.TextBox50);
            this.TabPage13.Controls.Add(this.Label69);
            this.TabPage13.Location = new System.Drawing.Point(4, 22);
            this.TabPage13.Name = "TabPage13";
            this.TabPage13.Padding = new System.Windows.Forms.Padding(3);
            this.TabPage13.Size = new System.Drawing.Size(619, 262);
            this.TabPage13.TabIndex = 5;
            this.TabPage13.Text = "Penal";
            this.TabPage13.UseVisualStyleBackColor = true;
            // 
            // Label80
            // 
            this.Label80.AutoSize = true;
            this.Label80.Location = new System.Drawing.Point(301, 168);
            this.Label80.Name = "Label80";
            this.Label80.Size = new System.Drawing.Size(77, 13);
            this.Label80.TabIndex = 22;
            this.Label80.Text = "Qualificadoras:";
            // 
            // TextBox59
            // 
            this.TextBox59.Location = new System.Drawing.Point(152, 184);
            this.TextBox59.Name = "TextBox59";
            this.TextBox59.Size = new System.Drawing.Size(143, 20);
            this.TextBox59.TabIndex = 21;
            // 
            // Label79
            // 
            this.Label79.AutoSize = true;
            this.Label79.Location = new System.Drawing.Point(149, 168);
            this.Label79.Name = "Label79";
            this.Label79.Size = new System.Drawing.Size(62, 13);
            this.Label79.TabIndex = 20;
            this.Label79.Text = "Minorantes:";
            // 
            // TextBox58
            // 
            this.TextBox58.Location = new System.Drawing.Point(6, 184);
            this.TextBox58.Name = "TextBox58";
            this.TextBox58.Size = new System.Drawing.Size(134, 20);
            this.TextBox58.TabIndex = 19;
            // 
            // Label78
            // 
            this.Label78.AutoSize = true;
            this.Label78.Location = new System.Drawing.Point(6, 168);
            this.Label78.Name = "Label78";
            this.Label78.Size = new System.Drawing.Size(62, 13);
            this.Label78.TabIndex = 18;
            this.Label78.Text = "Majorantes:";
            // 
            // TextBox57
            // 
            this.TextBox57.Location = new System.Drawing.Point(474, 145);
            this.TextBox57.Name = "TextBox57";
            this.TextBox57.Size = new System.Drawing.Size(139, 20);
            this.TextBox57.TabIndex = 17;
            // 
            // Label77
            // 
            this.Label77.AutoSize = true;
            this.Label77.Location = new System.Drawing.Point(471, 129);
            this.Label77.Name = "Label77";
            this.Label77.Size = new System.Drawing.Size(64, 13);
            this.Label77.TabIndex = 16;
            this.Label77.Text = "Agravantes:";
            // 
            // TextBox56
            // 
            this.TextBox56.Location = new System.Drawing.Point(304, 145);
            this.TextBox56.Name = "TextBox56";
            this.TextBox56.Size = new System.Drawing.Size(161, 20);
            this.TextBox56.TabIndex = 15;
            // 
            // Label76
            // 
            this.Label76.AutoSize = true;
            this.Label76.Location = new System.Drawing.Point(301, 129);
            this.Label76.Name = "Label76";
            this.Label76.Size = new System.Drawing.Size(64, 13);
            this.Label76.TabIndex = 14;
            this.Label76.Text = "Atenuantes:";
            // 
            // TextBox55
            // 
            this.TextBox55.Location = new System.Drawing.Point(149, 145);
            this.TextBox55.Name = "TextBox55";
            this.TextBox55.Size = new System.Drawing.Size(146, 20);
            this.TextBox55.TabIndex = 13;
            // 
            // Label75
            // 
            this.Label75.AutoSize = true;
            this.Label75.Location = new System.Drawing.Point(149, 129);
            this.Label75.Name = "Label75";
            this.Label75.Size = new System.Drawing.Size(88, 13);
            this.Label75.TabIndex = 12;
            this.Label75.Text = "Regime Prisional:";
            // 
            // TextBox54
            // 
            this.TextBox54.Location = new System.Drawing.Point(6, 145);
            this.TextBox54.Name = "TextBox54";
            this.TextBox54.Size = new System.Drawing.Size(134, 20);
            this.TextBox54.TabIndex = 11;
            // 
            // Label74
            // 
            this.Label74.AutoSize = true;
            this.Label74.Location = new System.Drawing.Point(6, 129);
            this.Label74.Name = "Label74";
            this.Label74.Size = new System.Drawing.Size(67, 13);
            this.Label74.TabIndex = 10;
            this.Label74.Text = "Reincidente:";
            // 
            // TextBox53
            // 
            this.TextBox53.Location = new System.Drawing.Point(301, 106);
            this.TextBox53.Name = "TextBox53";
            this.TextBox53.Size = new System.Drawing.Size(312, 20);
            this.TextBox53.TabIndex = 9;
            // 
            // Label73
            // 
            this.Label73.AutoSize = true;
            this.Label73.Location = new System.Drawing.Point(301, 90);
            this.Label73.Name = "Label73";
            this.Label73.Size = new System.Drawing.Size(120, 13);
            this.Label73.TabIndex = 8;
            this.Label73.Text = "Livramento Condicional:";
            // 
            // TextBox52
            // 
            this.TextBox52.Location = new System.Drawing.Point(6, 106);
            this.TextBox52.Name = "TextBox52";
            this.TextBox52.Size = new System.Drawing.Size(289, 20);
            this.TextBox52.TabIndex = 7;
            // 
            // Label72
            // 
            this.Label72.AutoSize = true;
            this.Label72.Location = new System.Drawing.Point(6, 90);
            this.Label72.Name = "Label72";
            this.Label72.Size = new System.Drawing.Size(186, 13);
            this.Label72.TabIndex = 6;
            this.Label72.Text = "Suspensão Condicional: do Processo:";
            // 
            // ComboBox1
            // 
            this.ComboBox1.FormattingEnabled = true;
            this.ComboBox1.Items.AddRange(new object[] {
            "Ordinário",
            "Sumário",
            "Sumaríssimo"});
            this.ComboBox1.Location = new System.Drawing.Point(474, 66);
            this.ComboBox1.Name = "ComboBox1";
            this.ComboBox1.Size = new System.Drawing.Size(139, 21);
            this.ComboBox1.TabIndex = 5;
            // 
            // Label71
            // 
            this.Label71.AutoSize = true;
            this.Label71.Location = new System.Drawing.Point(471, 51);
            this.Label71.Name = "Label71";
            this.Label71.Size = new System.Drawing.Size(84, 13);
            this.Label71.TabIndex = 4;
            this.Label71.Text = "Rito Processual:";
            // 
            // TextBox51
            // 
            this.TextBox51.Location = new System.Drawing.Point(6, 67);
            this.TextBox51.Name = "TextBox51";
            this.TextBox51.Size = new System.Drawing.Size(459, 20);
            this.TextBox51.TabIndex = 3;
            // 
            // Label70
            // 
            this.Label70.AutoSize = true;
            this.Label70.Location = new System.Drawing.Point(6, 51);
            this.Label70.Name = "Label70";
            this.Label70.Size = new System.Drawing.Size(65, 13);
            this.Label70.TabIndex = 2;
            this.Label70.Text = "Ação Penal:";
            // 
            // TextBox50
            // 
            this.TextBox50.Location = new System.Drawing.Point(6, 28);
            this.TextBox50.Name = "TextBox50";
            this.TextBox50.Size = new System.Drawing.Size(607, 20);
            this.TextBox50.TabIndex = 1;
            // 
            // Label69
            // 
            this.Label69.AutoSize = true;
            this.Label69.Location = new System.Drawing.Point(6, 12);
            this.Label69.Name = "Label69";
            this.Label69.Size = new System.Drawing.Size(36, 13);
            this.Label69.TabIndex = 0;
            this.Label69.Text = "Crime:";
            // 
            // TextBox36
            // 
            this.TextBox36.Location = new System.Drawing.Point(228, 17);
            this.TextBox36.Multiline = true;
            this.TextBox36.Name = "TextBox36";
            this.TextBox36.Size = new System.Drawing.Size(201, 63);
            this.TextBox36.TabIndex = 6;
            // 
            // Label19
            // 
            this.Label19.AutoSize = true;
            this.Label19.Location = new System.Drawing.Point(470, 166);
            this.Label19.Name = "Label19";
            this.Label19.Size = new System.Drawing.Size(87, 13);
            this.Label19.TabIndex = 88;
            this.Label19.Text = "CEP Residência:";
            // 
            // TextBox19
            // 
            this.TextBox19.Location = new System.Drawing.Point(14, 182);
            this.TextBox19.Name = "TextBox19";
            this.TextBox19.Size = new System.Drawing.Size(447, 20);
            this.TextBox19.TabIndex = 87;
            // 
            // Label20
            // 
            this.Label20.AutoSize = true;
            this.Label20.Location = new System.Drawing.Point(14, 166);
            this.Label20.Name = "Label20";
            this.Label20.Size = new System.Drawing.Size(63, 13);
            this.Label20.TabIndex = 86;
            this.Label20.Text = "Residência:";
            // 
            // txtEmail
            // 
            this.txtEmail.Location = new System.Drawing.Point(236, 233);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(228, 20);
            this.txtEmail.TabIndex = 71;
            // 
            // Label15
            // 
            this.Label15.AutoSize = true;
            this.Label15.Location = new System.Drawing.Point(233, 217);
            this.Label15.Name = "Label15";
            this.Label15.Size = new System.Drawing.Size(38, 13);
            this.Label15.TabIndex = 70;
            this.Label15.Text = "E-mail:";
            // 
            // Label11
            // 
            this.Label11.AutoSize = true;
            this.Label11.Location = new System.Drawing.Point(461, 63);
            this.Label11.Name = "Label11";
            this.Label11.Size = new System.Drawing.Size(65, 13);
            this.Label11.TabIndex = 68;
            this.Label11.Text = "Estado Civil:";
            // 
            // Label13
            // 
            this.Label13.AutoSize = true;
            this.Label13.Location = new System.Drawing.Point(121, 217);
            this.Label13.Name = "Label13";
            this.Label13.Size = new System.Drawing.Size(45, 13);
            this.Label13.TabIndex = 66;
            this.Label13.Text = "Celular: ";
            // 
            // Label12
            // 
            this.Label12.AutoSize = true;
            this.Label12.Location = new System.Drawing.Point(14, 217);
            this.Label12.Name = "Label12";
            this.Label12.Size = new System.Drawing.Size(55, 13);
            this.Label12.TabIndex = 64;
            this.Label12.Text = "Telefone: ";
            // 
            // Label10
            // 
            this.Label10.AutoSize = true;
            this.Label10.Location = new System.Drawing.Point(470, 166);
            this.Label10.Name = "Label10";
            this.Label10.Size = new System.Drawing.Size(87, 13);
            this.Label10.TabIndex = 60;
            this.Label10.Text = "CEP Residência:";
            // 
            // txtResidencia
            // 
            this.txtResidencia.Location = new System.Drawing.Point(14, 182);
            this.txtResidencia.Name = "txtResidencia";
            this.txtResidencia.Size = new System.Drawing.Size(447, 20);
            this.txtResidencia.TabIndex = 59;
            // 
            // Label17
            // 
            this.Label17.AutoSize = true;
            this.Label17.Location = new System.Drawing.Point(121, 217);
            this.Label17.Name = "Label17";
            this.Label17.Size = new System.Drawing.Size(45, 13);
            this.Label17.TabIndex = 92;
            this.Label17.Text = "Celular: ";
            // 
            // Label18
            // 
            this.Label18.AutoSize = true;
            this.Label18.Location = new System.Drawing.Point(14, 217);
            this.Label18.Name = "Label18";
            this.Label18.Size = new System.Drawing.Size(55, 13);
            this.Label18.TabIndex = 90;
            this.Label18.Text = "Telefone: ";
            // 
            // Label9
            // 
            this.Label9.AutoSize = true;
            this.Label9.Location = new System.Drawing.Point(14, 166);
            this.Label9.Name = "Label9";
            this.Label9.Size = new System.Drawing.Size(63, 13);
            this.Label9.TabIndex = 58;
            this.Label9.Text = "Residência:";
            // 
            // Label8
            // 
            this.Label8.AutoSize = true;
            this.Label8.Location = new System.Drawing.Point(470, 113);
            this.Label8.Name = "Label8";
            this.Label8.Size = new System.Drawing.Size(76, 13);
            this.Label8.TabIndex = 56;
            this.Label8.Text = "CEP Domicilio:";
            // 
            // txtDomicilio
            // 
            this.txtDomicilio.Location = new System.Drawing.Point(14, 129);
            this.txtDomicilio.Name = "txtDomicilio";
            this.txtDomicilio.Size = new System.Drawing.Size(447, 20);
            this.txtDomicilio.TabIndex = 55;
            // 
            // txtNacionalidade
            // 
            this.txtNacionalidade.Location = new System.Drawing.Point(331, 79);
            this.txtNacionalidade.Name = "txtNacionalidade";
            this.txtNacionalidade.Size = new System.Drawing.Size(123, 20);
            this.txtNacionalidade.TabIndex = 53;
            // 
            // Label6
            // 
            this.Label6.AutoSize = true;
            this.Label6.Location = new System.Drawing.Point(328, 63);
            this.Label6.Name = "Label6";
            this.Label6.Size = new System.Drawing.Size(81, 13);
            this.Label6.TabIndex = 52;
            this.Label6.Text = "Nacionalidade: ";
            // 
            // Label16
            // 
            this.Label16.AutoSize = true;
            this.Label16.Location = new System.Drawing.Point(461, 63);
            this.Label16.Name = "Label16";
            this.Label16.Size = new System.Drawing.Size(65, 13);
            this.Label16.TabIndex = 94;
            this.Label16.Text = "Estado Civil:";
            // 
            // Label21
            // 
            this.Label21.AutoSize = true;
            this.Label21.Location = new System.Drawing.Point(470, 113);
            this.Label21.Name = "Label21";
            this.Label21.Size = new System.Drawing.Size(76, 13);
            this.Label21.TabIndex = 84;
            this.Label21.Text = "CEP Domicilio:";
            // 
            // TextBox21
            // 
            this.TextBox21.Location = new System.Drawing.Point(14, 129);
            this.TextBox21.Name = "TextBox21";
            this.TextBox21.Size = new System.Drawing.Size(447, 20);
            this.TextBox21.TabIndex = 83;
            // 
            // Label22
            // 
            this.Label22.AutoSize = true;
            this.Label22.Location = new System.Drawing.Point(14, 113);
            this.Label22.Name = "Label22";
            this.Label22.Size = new System.Drawing.Size(52, 13);
            this.Label22.TabIndex = 82;
            this.Label22.Text = "Domicilio:";
            // 
            // Label7
            // 
            this.Label7.AutoSize = true;
            this.Label7.Location = new System.Drawing.Point(14, 113);
            this.Label7.Name = "Label7";
            this.Label7.Size = new System.Drawing.Size(52, 13);
            this.Label7.TabIndex = 54;
            this.Label7.Text = "Domicilio:";
            // 
            // Panel1
            // 
            this.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Panel1.Controls.Add(this.Button8);
            this.Panel1.Controls.Add(this.Button7);
            this.Panel1.Controls.Add(this.RadioButton2);
            this.Panel1.Controls.Add(this.RadioButton1);
            this.Panel1.Controls.Add(this.TextBox36);
            this.Panel1.Controls.Add(this.Label43);
            this.Panel1.Controls.Add(this.TextBox35);
            this.Panel1.Controls.Add(this.Label42);
            this.Panel1.Controls.Add(this.TextBox34);
            this.Panel1.Controls.Add(this.Label41);
            this.Panel1.Controls.Add(this.DataGridView2);
            this.Panel1.Location = new System.Drawing.Point(150, 22);
            this.Panel1.Name = "Panel1";
            this.Panel1.Size = new System.Drawing.Size(449, 207);
            this.Panel1.TabIndex = 33;
            // 
            // Label43
            // 
            this.Label43.AutoSize = true;
            this.Label43.Location = new System.Drawing.Point(190, 17);
            this.Label43.Name = "Label43";
            this.Label43.Size = new System.Drawing.Size(32, 13);
            this.Label43.TabIndex = 5;
            this.Label43.Text = "Obs.:";
            // 
            // TextBox35
            // 
            this.TextBox35.Location = new System.Drawing.Point(10, 85);
            this.TextBox35.Name = "TextBox35";
            this.TextBox35.Size = new System.Drawing.Size(168, 20);
            this.TextBox35.TabIndex = 4;
            // 
            // Label42
            // 
            this.Label42.AutoSize = true;
            this.Label42.Location = new System.Drawing.Point(10, 67);
            this.Label42.Name = "Label42";
            this.Label42.Size = new System.Drawing.Size(117, 13);
            this.Label42.TabIndex = 3;
            this.Label42.Text = "Valor Estimado do Ben:";
            // 
            // TextBox34
            // 
            this.TextBox34.Location = new System.Drawing.Point(10, 33);
            this.TextBox34.Name = "TextBox34";
            this.TextBox34.Size = new System.Drawing.Size(168, 20);
            this.TextBox34.TabIndex = 2;
            // 
            // Label41
            // 
            this.Label41.AutoSize = true;
            this.Label41.Location = new System.Drawing.Point(10, 17);
            this.Label41.Name = "Label41";
            this.Label41.Size = new System.Drawing.Size(58, 13);
            this.Label41.TabIndex = 1;
            this.Label41.Text = "Descrição:";
            // 
            // DataGridView2
            // 
            this.DataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DataGridView2.Location = new System.Drawing.Point(26, 111);
            this.DataGridView2.Name = "DataGridView2";
            this.DataGridView2.Size = new System.Drawing.Size(403, 65);
            this.DataGridView2.TabIndex = 0;
            // 
            // Label5
            // 
            this.Label5.AutoSize = true;
            this.Label5.Location = new System.Drawing.Point(189, 63);
            this.Label5.Name = "Label5";
            this.Label5.Size = new System.Drawing.Size(92, 13);
            this.Label5.TabIndex = 50;
            this.Label5.Text = "Data Nascimento:";
            // 
            // TextBox13
            // 
            this.TextBox13.Location = new System.Drawing.Point(236, 233);
            this.TextBox13.Name = "TextBox13";
            this.TextBox13.Size = new System.Drawing.Size(225, 20);
            this.TextBox13.TabIndex = 97;
            // 
            // TabPage2
            // 
            this.TabPage2.Controls.Add(this.label31);
            this.TabPage2.Controls.Add(this.maskedTextBox6);
            this.TabPage2.Controls.Add(this.maskedTextBox7);
            this.TabPage2.Controls.Add(this.maskedTextBox8);
            this.TabPage2.Controls.Add(this.maskedTextBox9);
            this.TabPage2.Controls.Add(this.maskedTextBox10);
            this.TabPage2.Controls.Add(this.dateTimePicker2);
            this.TabPage2.Controls.Add(this.comboBox7);
            this.TabPage2.Controls.Add(this.comboBox8);
            this.TabPage2.Controls.Add(this.TextBox13);
            this.TabPage2.Controls.Add(this.Label14);
            this.TabPage2.Controls.Add(this.Label16);
            this.TabPage2.Controls.Add(this.Label17);
            this.TabPage2.Controls.Add(this.Label18);
            this.TabPage2.Controls.Add(this.Label19);
            this.TabPage2.Controls.Add(this.TextBox19);
            this.TabPage2.Controls.Add(this.Label20);
            this.TabPage2.Controls.Add(this.Label21);
            this.TabPage2.Controls.Add(this.TextBox21);
            this.TabPage2.Controls.Add(this.Label22);
            this.TabPage2.Controls.Add(this.TextBox22);
            this.TabPage2.Controls.Add(this.Label23);
            this.TabPage2.Controls.Add(this.Label24);
            this.TabPage2.Controls.Add(this.TextBox24);
            this.TabPage2.Controls.Add(this.Label25);
            this.TabPage2.Controls.Add(this.Label26);
            this.TabPage2.Controls.Add(this.TextBox26);
            this.TabPage2.Controls.Add(this.Label27);
            this.TabPage2.Location = new System.Drawing.Point(4, 22);
            this.TabPage2.Name = "TabPage2";
            this.TabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.TabPage2.Size = new System.Drawing.Size(619, 262);
            this.TabPage2.TabIndex = 1;
            this.TabPage2.Text = "Dados do Cônjuge";
            this.TabPage2.UseVisualStyleBackColor = true;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(470, 216);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(34, 13);
            this.label31.TabIndex = 106;
            this.label31.Text = "Sexo:";
            // 
            // maskedTextBox6
            // 
            this.maskedTextBox6.Location = new System.Drawing.Point(421, 28);
            this.maskedTextBox6.Mask = "000.000.000-00";
            this.maskedTextBox6.Name = "maskedTextBox6";
            this.maskedTextBox6.Size = new System.Drawing.Size(174, 20);
            this.maskedTextBox6.TabIndex = 105;
            // 
            // maskedTextBox7
            // 
            this.maskedTextBox7.Location = new System.Drawing.Point(467, 181);
            this.maskedTextBox7.Mask = "00000-000";
            this.maskedTextBox7.Name = "maskedTextBox7";
            this.maskedTextBox7.Size = new System.Drawing.Size(128, 20);
            this.maskedTextBox7.TabIndex = 104;
            // 
            // maskedTextBox8
            // 
            this.maskedTextBox8.Location = new System.Drawing.Point(469, 130);
            this.maskedTextBox8.Mask = "00000-000";
            this.maskedTextBox8.Name = "maskedTextBox8";
            this.maskedTextBox8.Size = new System.Drawing.Size(128, 20);
            this.maskedTextBox8.TabIndex = 103;
            // 
            // maskedTextBox9
            // 
            this.maskedTextBox9.Location = new System.Drawing.Point(117, 232);
            this.maskedTextBox9.Mask = "(00) 00000-0000";
            this.maskedTextBox9.Name = "maskedTextBox9";
            this.maskedTextBox9.Size = new System.Drawing.Size(100, 20);
            this.maskedTextBox9.TabIndex = 102;
            // 
            // maskedTextBox10
            // 
            this.maskedTextBox10.Location = new System.Drawing.Point(11, 232);
            this.maskedTextBox10.Mask = "(00) 0000-0000";
            this.maskedTextBox10.Name = "maskedTextBox10";
            this.maskedTextBox10.Size = new System.Drawing.Size(100, 20);
            this.maskedTextBox10.TabIndex = 101;
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePicker2.Location = new System.Drawing.Point(186, 79);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(119, 20);
            this.dateTimePicker2.TabIndex = 100;
            // 
            // comboBox7
            // 
            this.comboBox7.FormattingEnabled = true;
            this.comboBox7.Items.AddRange(new object[] {
            "SOLTEIRO",
            "CASADO",
            "SEPARADO",
            "DIVORCIADO",
            "VIÚVO"});
            this.comboBox7.Location = new System.Drawing.Point(458, 78);
            this.comboBox7.Name = "comboBox7";
            this.comboBox7.Size = new System.Drawing.Size(139, 21);
            this.comboBox7.TabIndex = 99;
            // 
            // comboBox8
            // 
            this.comboBox8.FormattingEnabled = true;
            this.comboBox8.Items.AddRange(new object[] {
            "FEMININO",
            "MASCULINO"});
            this.comboBox8.Location = new System.Drawing.Point(467, 232);
            this.comboBox8.Name = "comboBox8";
            this.comboBox8.Size = new System.Drawing.Size(130, 21);
            this.comboBox8.TabIndex = 98;
            // 
            // Label14
            // 
            this.Label14.AutoSize = true;
            this.Label14.Location = new System.Drawing.Point(233, 217);
            this.Label14.Name = "Label14";
            this.Label14.Size = new System.Drawing.Size(38, 13);
            this.Label14.TabIndex = 96;
            this.Label14.Text = "E-mail:";
            // 
            // TextBox22
            // 
            this.TextBox22.Location = new System.Drawing.Point(331, 79);
            this.TextBox22.Name = "TextBox22";
            this.TextBox22.Size = new System.Drawing.Size(123, 20);
            this.TextBox22.TabIndex = 81;
            // 
            // Label23
            // 
            this.Label23.AutoSize = true;
            this.Label23.Location = new System.Drawing.Point(328, 63);
            this.Label23.Name = "Label23";
            this.Label23.Size = new System.Drawing.Size(81, 13);
            this.Label23.TabIndex = 80;
            this.Label23.Text = "Nacionalidade: ";
            // 
            // Label24
            // 
            this.Label24.AutoSize = true;
            this.Label24.Location = new System.Drawing.Point(189, 63);
            this.Label24.Name = "Label24";
            this.Label24.Size = new System.Drawing.Size(92, 13);
            this.Label24.TabIndex = 78;
            this.Label24.Text = "Data Nascimento:";
            // 
            // TextBox24
            // 
            this.TextBox24.Location = new System.Drawing.Point(14, 79);
            this.TextBox24.Name = "TextBox24";
            this.TextBox24.Size = new System.Drawing.Size(166, 20);
            this.TextBox24.TabIndex = 77;
            // 
            // Label25
            // 
            this.Label25.AutoSize = true;
            this.Label25.Location = new System.Drawing.Point(14, 63);
            this.Label25.Name = "Label25";
            this.Label25.Size = new System.Drawing.Size(26, 13);
            this.Label25.TabIndex = 76;
            this.Label25.Text = "RG:";
            // 
            // Label26
            // 
            this.Label26.AutoSize = true;
            this.Label26.Location = new System.Drawing.Point(424, 13);
            this.Label26.Name = "Label26";
            this.Label26.Size = new System.Drawing.Size(30, 13);
            this.Label26.TabIndex = 74;
            this.Label26.Text = "CPF:";
            // 
            // TextBox26
            // 
            this.TextBox26.Location = new System.Drawing.Point(14, 29);
            this.TextBox26.Name = "TextBox26";
            this.TextBox26.Size = new System.Drawing.Size(401, 20);
            this.TextBox26.TabIndex = 73;
            // 
            // Label27
            // 
            this.Label27.AutoSize = true;
            this.Label27.Location = new System.Drawing.Point(14, 13);
            this.Label27.Name = "Label27";
            this.Label27.Size = new System.Drawing.Size(38, 13);
            this.Label27.TabIndex = 72;
            this.Label27.Text = "Nome:";
            // 
            // txtRG
            // 
            this.txtRG.Location = new System.Drawing.Point(14, 79);
            this.txtRG.Name = "txtRG";
            this.txtRG.Size = new System.Drawing.Size(166, 20);
            this.txtRG.TabIndex = 49;
            // 
            // Label4
            // 
            this.Label4.AutoSize = true;
            this.Label4.Location = new System.Drawing.Point(14, 63);
            this.Label4.Name = "Label4";
            this.Label4.Size = new System.Drawing.Size(26, 13);
            this.Label4.TabIndex = 48;
            this.Label4.Text = "RG:";
            // 
            // Label3
            // 
            this.Label3.AutoSize = true;
            this.Label3.Location = new System.Drawing.Point(424, 13);
            this.Label3.Name = "Label3";
            this.Label3.Size = new System.Drawing.Size(30, 13);
            this.Label3.TabIndex = 46;
            this.Label3.Text = "CPF:";
            // 
            // txtnome
            // 
            this.txtnome.Location = new System.Drawing.Point(14, 29);
            this.txtnome.Name = "txtnome";
            this.txtnome.Size = new System.Drawing.Size(401, 20);
            this.txtnome.TabIndex = 45;
            // 
            // Label2
            // 
            this.Label2.AutoSize = true;
            this.Label2.Location = new System.Drawing.Point(14, 13);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(38, 13);
            this.Label2.TabIndex = 44;
            this.Label2.Text = "Nome:";
            // 
            // TabPage1
            // 
            this.TabPage1.Controls.Add(this.mktCPF);
            this.TabPage1.Controls.Add(this.mktCepResidencia);
            this.TabPage1.Controls.Add(this.mktCepDomicilio);
            this.TabPage1.Controls.Add(this.mktCelular);
            this.TabPage1.Controls.Add(this.mktTelefone);
            this.TabPage1.Controls.Add(this.dtpDataNascimento);
            this.TabPage1.Controls.Add(this.cmbEstadoCivil);
            this.TabPage1.Controls.Add(this.cmbSexo);
            this.TabPage1.Controls.Add(this.label29);
            this.TabPage1.Controls.Add(this.txtEmail);
            this.TabPage1.Controls.Add(this.Label15);
            this.TabPage1.Controls.Add(this.Label11);
            this.TabPage1.Controls.Add(this.Label13);
            this.TabPage1.Controls.Add(this.Label12);
            this.TabPage1.Controls.Add(this.Label10);
            this.TabPage1.Controls.Add(this.txtResidencia);
            this.TabPage1.Controls.Add(this.Label9);
            this.TabPage1.Controls.Add(this.Label8);
            this.TabPage1.Controls.Add(this.txtDomicilio);
            this.TabPage1.Controls.Add(this.Label7);
            this.TabPage1.Controls.Add(this.txtNacionalidade);
            this.TabPage1.Controls.Add(this.Label6);
            this.TabPage1.Controls.Add(this.Label5);
            this.TabPage1.Controls.Add(this.txtRG);
            this.TabPage1.Controls.Add(this.Label4);
            this.TabPage1.Controls.Add(this.Label3);
            this.TabPage1.Controls.Add(this.txtnome);
            this.TabPage1.Controls.Add(this.Label2);
            this.TabPage1.Location = new System.Drawing.Point(4, 22);
            this.TabPage1.Name = "TabPage1";
            this.TabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.TabPage1.Size = new System.Drawing.Size(619, 262);
            this.TabPage1.TabIndex = 0;
            this.TabPage1.Text = "Dados Cliente";
            this.TabPage1.UseVisualStyleBackColor = true;
            // 
            // mktCPF
            // 
            this.mktCPF.Location = new System.Drawing.Point(427, 29);
            this.mktCPF.Mask = "000.000.000-00";
            this.mktCPF.Name = "mktCPF";
            this.mktCPF.Size = new System.Drawing.Size(174, 20);
            this.mktCPF.TabIndex = 80;
            // 
            // mktCepResidencia
            // 
            this.mktCepResidencia.Location = new System.Drawing.Point(473, 182);
            this.mktCepResidencia.Mask = "00000-000";
            this.mktCepResidencia.Name = "mktCepResidencia";
            this.mktCepResidencia.Size = new System.Drawing.Size(128, 20);
            this.mktCepResidencia.TabIndex = 79;
            // 
            // mktCepDomicilio
            // 
            this.mktCepDomicilio.Location = new System.Drawing.Point(475, 131);
            this.mktCepDomicilio.Mask = "00000-000";
            this.mktCepDomicilio.Name = "mktCepDomicilio";
            this.mktCepDomicilio.Size = new System.Drawing.Size(128, 20);
            this.mktCepDomicilio.TabIndex = 78;
            // 
            // mktCelular
            // 
            this.mktCelular.Location = new System.Drawing.Point(123, 233);
            this.mktCelular.Mask = "(00) 00000-0000";
            this.mktCelular.Name = "mktCelular";
            this.mktCelular.Size = new System.Drawing.Size(100, 20);
            this.mktCelular.TabIndex = 77;
            // 
            // mktTelefone
            // 
            this.mktTelefone.Location = new System.Drawing.Point(17, 233);
            this.mktTelefone.Mask = "(00) 0000-0000";
            this.mktTelefone.Name = "mktTelefone";
            this.mktTelefone.Size = new System.Drawing.Size(100, 20);
            this.mktTelefone.TabIndex = 76;
            // 
            // dtpDataNascimento
            // 
            this.dtpDataNascimento.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpDataNascimento.Location = new System.Drawing.Point(192, 80);
            this.dtpDataNascimento.Name = "dtpDataNascimento";
            this.dtpDataNascimento.Size = new System.Drawing.Size(119, 20);
            this.dtpDataNascimento.TabIndex = 75;
            // 
            // cmbEstadoCivil
            // 
            this.cmbEstadoCivil.FormattingEnabled = true;
            this.cmbEstadoCivil.Items.AddRange(new object[] {
            "SOLTEIRO",
            "CASADO",
            "SEPARADO",
            "DIVORCIADO",
            "VIÚVO"});
            this.cmbEstadoCivil.Location = new System.Drawing.Point(464, 79);
            this.cmbEstadoCivil.Name = "cmbEstadoCivil";
            this.cmbEstadoCivil.Size = new System.Drawing.Size(139, 21);
            this.cmbEstadoCivil.TabIndex = 74;
            // 
            // cmbSexo
            // 
            this.cmbSexo.FormattingEnabled = true;
            this.cmbSexo.Items.AddRange(new object[] {
            "FEMININO",
            "MASCULINO"});
            this.cmbSexo.Location = new System.Drawing.Point(473, 233);
            this.cmbSexo.Name = "cmbSexo";
            this.cmbSexo.Size = new System.Drawing.Size(130, 21);
            this.cmbSexo.TabIndex = 73;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(470, 217);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(34, 13);
            this.label29.TabIndex = 72;
            this.label29.Text = "Sexo:";
            // 
            // TabControl1
            // 
            this.TabControl1.Controls.Add(this.TabPage1);
            this.TabControl1.Controls.Add(this.TabPage2);
            this.TabControl1.Controls.Add(this.TabPage3);
            this.TabControl1.Controls.Add(this.TabPage4);
            this.TabControl1.Controls.Add(this.TabPage10);
            this.TabControl1.Controls.Add(this.TabPage13);
            this.TabControl1.Location = new System.Drawing.Point(6, 7);
            this.TabControl1.Name = "TabControl1";
            this.TabControl1.SelectedIndex = 0;
            this.TabControl1.Size = new System.Drawing.Size(627, 288);
            this.TabControl1.TabIndex = 53;
            // 
            // TabPage3
            // 
            this.TabPage3.Controls.Add(this.TabControl2);
            this.TabPage3.Location = new System.Drawing.Point(4, 22);
            this.TabPage3.Name = "TabPage3";
            this.TabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.TabPage3.Size = new System.Drawing.Size(619, 262);
            this.TabPage3.TabIndex = 2;
            this.TabPage3.Text = "Cível / Direto de Família";
            this.TabPage3.UseVisualStyleBackColor = true;
            // 
            // TabControl2
            // 
            this.TabControl2.Controls.Add(this.TabPage5);
            this.TabControl2.Controls.Add(this.TabPage6);
            this.TabControl2.Controls.Add(this.TabPage7);
            this.TabControl2.Location = new System.Drawing.Point(3, 5);
            this.TabControl2.Name = "TabControl2";
            this.TabControl2.SelectedIndex = 0;
            this.TabControl2.Size = new System.Drawing.Size(613, 261);
            this.TabControl2.TabIndex = 0;
            // 
            // TabPage5
            // 
            this.TabPage5.Controls.Add(this.Button10);
            this.TabPage5.Controls.Add(this.ComboBox2);
            this.TabPage5.Location = new System.Drawing.Point(4, 22);
            this.TabPage5.Name = "TabPage5";
            this.TabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.TabPage5.Size = new System.Drawing.Size(605, 235);
            this.TabPage5.TabIndex = 0;
            this.TabPage5.Text = "Anexos";
            this.TabPage5.UseVisualStyleBackColor = true;
            // 
            // Button10
            // 
            this.Button10.Location = new System.Drawing.Point(401, 20);
            this.Button10.Name = "Button10";
            this.Button10.Size = new System.Drawing.Size(135, 23);
            this.Button10.TabIndex = 29;
            this.Button10.Text = "Anexar";
            this.Button10.UseVisualStyleBackColor = true;
            // 
            // ComboBox2
            // 
            this.ComboBox2.FormattingEnabled = true;
            this.ComboBox2.Items.AddRange(new object[] {
            "Comprovante de Renda",
            "Certidão de Casamento",
            "Certidão de Nascimento",
            "Sentença Pensão Alimentícia"});
            this.ComboBox2.Location = new System.Drawing.Point(38, 20);
            this.ComboBox2.Name = "ComboBox2";
            this.ComboBox2.Size = new System.Drawing.Size(303, 21);
            this.ComboBox2.TabIndex = 28;
            // 
            // TabPage6
            // 
            this.TabPage6.Controls.Add(this.label30);
            this.TabPage6.Controls.Add(this.label1);
            this.TabPage6.Controls.Add(this.textBox62);
            this.TabPage6.Controls.Add(this.textBox61);
            this.TabPage6.Controls.Add(this.Button9);
            this.TabPage6.Controls.Add(this.Button6);
            this.TabPage6.Controls.Add(this.Button5);
            this.TabPage6.Controls.Add(this.TextBox30);
            this.TabPage6.Controls.Add(this.Label36);
            this.TabPage6.Controls.Add(this.TextBox29);
            this.TabPage6.Controls.Add(this.Label35);
            this.TabPage6.Controls.Add(this.TextBox28);
            this.TabPage6.Controls.Add(this.Label34);
            this.TabPage6.Controls.Add(this.TextBox27);
            this.TabPage6.Controls.Add(this.Label33);
            this.TabPage6.Controls.Add(this.DataGridView1);
            this.TabPage6.Location = new System.Drawing.Point(4, 22);
            this.TabPage6.Name = "TabPage6";
            this.TabPage6.Padding = new System.Windows.Forms.Padding(3);
            this.TabPage6.Size = new System.Drawing.Size(605, 235);
            this.TabPage6.TabIndex = 1;
            this.TabPage6.Text = "Dados dos Filhos";
            this.TabPage6.UseVisualStyleBackColor = true;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(210, 108);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(29, 13);
            this.label30.TabIndex = 26;
            this.label30.Text = "Obs:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(24, 108);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(34, 13);
            this.label1.TabIndex = 25;
            this.label1.Text = "Sexo:";
            // 
            // textBox62
            // 
            this.textBox62.Location = new System.Drawing.Point(204, 124);
            this.textBox62.Name = "textBox62";
            this.textBox62.Size = new System.Drawing.Size(171, 20);
            this.textBox62.TabIndex = 24;
            // 
            // textBox61
            // 
            this.textBox61.Location = new System.Drawing.Point(24, 124);
            this.textBox61.Name = "textBox61";
            this.textBox61.Size = new System.Drawing.Size(171, 20);
            this.textBox61.TabIndex = 23;
            // 
            // Button9
            // 
            this.Button9.Location = new System.Drawing.Point(482, 17);
            this.Button9.Name = "Button9";
            this.Button9.Size = new System.Drawing.Size(75, 23);
            this.Button9.TabIndex = 22;
            this.Button9.Text = "Novo";
            this.Button9.UseVisualStyleBackColor = true;
            // 
            // Button6
            // 
            this.Button6.Location = new System.Drawing.Point(482, 75);
            this.Button6.Name = "Button6";
            this.Button6.Size = new System.Drawing.Size(75, 23);
            this.Button6.TabIndex = 21;
            this.Button6.Text = "Excluir";
            this.Button6.UseVisualStyleBackColor = true;
            // 
            // Button5
            // 
            this.Button5.Location = new System.Drawing.Point(482, 46);
            this.Button5.Name = "Button5";
            this.Button5.Size = new System.Drawing.Size(75, 23);
            this.Button5.TabIndex = 20;
            this.Button5.Text = "Salvar";
            this.Button5.UseVisualStyleBackColor = true;
            // 
            // TextBox30
            // 
            this.TextBox30.Location = new System.Drawing.Point(204, 75);
            this.TextBox30.Name = "TextBox30";
            this.TextBox30.Size = new System.Drawing.Size(130, 20);
            this.TextBox30.TabIndex = 19;
            // 
            // Label36
            // 
            this.Label36.AutoSize = true;
            this.Label36.Location = new System.Drawing.Point(201, 60);
            this.Label36.Name = "Label36";
            this.Label36.Size = new System.Drawing.Size(23, 13);
            this.Label36.TabIndex = 18;
            this.Label36.Text = "RG";
            // 
            // TextBox29
            // 
            this.TextBox29.Location = new System.Drawing.Point(24, 75);
            this.TextBox29.Name = "TextBox29";
            this.TextBox29.Size = new System.Drawing.Size(171, 20);
            this.TextBox29.TabIndex = 17;
            // 
            // Label35
            // 
            this.Label35.AutoSize = true;
            this.Label35.Location = new System.Drawing.Point(21, 60);
            this.Label35.Name = "Label35";
            this.Label35.Size = new System.Drawing.Size(30, 13);
            this.Label35.TabIndex = 16;
            this.Label35.Text = "CPF:";
            // 
            // TextBox28
            // 
            this.TextBox28.Location = new System.Drawing.Point(276, 34);
            this.TextBox28.Name = "TextBox28";
            this.TextBox28.Size = new System.Drawing.Size(125, 20);
            this.TextBox28.TabIndex = 15;
            // 
            // Label34
            // 
            this.Label34.AutoSize = true;
            this.Label34.Location = new System.Drawing.Point(271, 18);
            this.Label34.Name = "Label34";
            this.Label34.Size = new System.Drawing.Size(92, 13);
            this.Label34.TabIndex = 14;
            this.Label34.Text = "Data Nascimento:";
            // 
            // TextBox27
            // 
            this.TextBox27.Location = new System.Drawing.Point(24, 34);
            this.TextBox27.Name = "TextBox27";
            this.TextBox27.Size = new System.Drawing.Size(241, 20);
            this.TextBox27.TabIndex = 13;
            // 
            // Label33
            // 
            this.Label33.AutoSize = true;
            this.Label33.Location = new System.Drawing.Point(21, 18);
            this.Label33.Name = "Label33";
            this.Label33.Size = new System.Drawing.Size(38, 13);
            this.Label33.TabIndex = 12;
            this.Label33.Text = "Nome:";
            // 
            // DataGridView1
            // 
            this.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DataGridView1.Location = new System.Drawing.Point(24, 150);
            this.DataGridView1.Name = "DataGridView1";
            this.DataGridView1.Size = new System.Drawing.Size(533, 54);
            this.DataGridView1.TabIndex = 11;
            // 
            // TabPage7
            // 
            this.TabPage7.Controls.Add(this.Label37);
            this.TabPage7.Controls.Add(this.Panel1);
            this.TabPage7.Controls.Add(this.Label32);
            this.TabPage7.Controls.Add(this.Panel2);
            this.TabPage7.Location = new System.Drawing.Point(4, 22);
            this.TabPage7.Name = "TabPage7";
            this.TabPage7.Padding = new System.Windows.Forms.Padding(3);
            this.TabPage7.Size = new System.Drawing.Size(605, 235);
            this.TabPage7.TabIndex = 2;
            this.TabPage7.Text = "Dados Bancarios e Bens";
            this.TabPage7.UseVisualStyleBackColor = true;
            // 
            // Label37
            // 
            this.Label37.AutoSize = true;
            this.Label37.Location = new System.Drawing.Point(161, 15);
            this.Label37.Name = "Label37";
            this.Label37.Size = new System.Drawing.Size(92, 13);
            this.Label37.TabIndex = 34;
            this.Label37.Text = "Relação de Bens:";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnSalvar);
            this.groupBox1.Controls.Add(this.button2);
            this.groupBox1.Location = new System.Drawing.Point(13, 297);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(615, 53);
            this.groupBox1.TabIndex = 54;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Navegação:";
            // 
            // btnSalvar
            // 
            this.btnSalvar.Location = new System.Drawing.Point(338, 15);
            this.btnSalvar.Name = "btnSalvar";
            this.btnSalvar.Size = new System.Drawing.Size(152, 28);
            this.btnSalvar.TabIndex = 2;
            this.btnSalvar.Text = "Salvar Dados Cliente";
            this.btnSalvar.UseVisualStyleBackColor = true;
            this.btnSalvar.Click += new System.EventHandler(this.button3_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(513, 13);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(87, 31);
            this.button2.TabIndex = 1;
            this.button2.Text = "Sair";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // FrmClienteCadastro
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(637, 353);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.TabControl1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "FrmClienteCadastro";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Cliente";
            this.TabPage9.ResumeLayout(false);
            this.TabPage9.PerformLayout();
            this.TabPage10.ResumeLayout(false);
            this.TabControl4.ResumeLayout(false);
            this.TabPage11.ResumeLayout(false);
            this.TabPage11.PerformLayout();
            this.TabPage12.ResumeLayout(false);
            this.TabPage12.PerformLayout();
            this.Panel2.ResumeLayout(false);
            this.Panel2.PerformLayout();
            this.TabPage4.ResumeLayout(false);
            this.TabControl3.ResumeLayout(false);
            this.TabPage8.ResumeLayout(false);
            this.TabPage13.ResumeLayout(false);
            this.TabPage13.PerformLayout();
            this.Panel1.ResumeLayout(false);
            this.Panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DataGridView2)).EndInit();
            this.TabPage2.ResumeLayout(false);
            this.TabPage2.PerformLayout();
            this.TabPage1.ResumeLayout(false);
            this.TabPage1.PerformLayout();
            this.TabControl1.ResumeLayout(false);
            this.TabPage3.ResumeLayout(false);
            this.TabControl2.ResumeLayout(false);
            this.TabPage5.ResumeLayout(false);
            this.TabPage6.ResumeLayout(false);
            this.TabPage6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DataGridView1)).EndInit();
            this.TabPage7.ResumeLayout(false);
            this.TabPage7.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        internal System.Windows.Forms.TabPage TabPage9;
        internal System.Windows.Forms.TextBox TextBox44;
        internal System.Windows.Forms.Label Label60;
        internal System.Windows.Forms.TextBox TextBox43;
        internal System.Windows.Forms.Label Label59;
        internal System.Windows.Forms.TextBox TextBox42;
        internal System.Windows.Forms.Label Label58;
        internal System.Windows.Forms.TextBox TextBox41;
        internal System.Windows.Forms.Label Label57;
        internal System.Windows.Forms.TextBox TextBox40;
        internal System.Windows.Forms.Label Label56;
        internal System.Windows.Forms.TextBox TextBox39;
        internal System.Windows.Forms.Label Label55;
        internal System.Windows.Forms.TextBox TextBox38;
        internal System.Windows.Forms.Label Label54;
        internal System.Windows.Forms.TextBox TextBox37;
        internal System.Windows.Forms.Label Label53;
        internal System.Windows.Forms.TabPage TabPage10;
        internal System.Windows.Forms.TabControl TabControl4;
        internal System.Windows.Forms.TabPage TabPage11;
        internal System.Windows.Forms.Button BtnCartaConcessaoMemorialCalculo;
        internal System.Windows.Forms.TextBox TxbCartaConcessaoMemorialCalculo;
        internal System.Windows.Forms.Label Label63;
        internal System.Windows.Forms.Button BtnCartaIndeferimentoBeneficioRequerido;
        internal System.Windows.Forms.TextBox TxtCartaIndeferimentoBeneficioRequerido;
        internal System.Windows.Forms.Label Label62;
        internal System.Windows.Forms.Button BtnGuiaRecolhimentoContribuicoesPrevidenciario;
        internal System.Windows.Forms.TextBox TxtGuiaRecolhimentoContribuicoesPrevidenciario;
        internal System.Windows.Forms.Label Label61;
        internal System.Windows.Forms.TabPage TabPage12;
        internal System.Windows.Forms.TextBox TextBox49;
        internal System.Windows.Forms.Label Label68;
        internal System.Windows.Forms.TextBox TextBox48;
        internal System.Windows.Forms.Label Label67;
        internal System.Windows.Forms.TextBox TextBox47;
        internal System.Windows.Forms.Label Label66;
        internal System.Windows.Forms.TextBox TextBox46;
        internal System.Windows.Forms.Label Label65;
        internal System.Windows.Forms.TextBox TextBox45;
        internal System.Windows.Forms.Label Label64;
        internal System.Windows.Forms.Button Button8;
        internal System.Windows.Forms.RadioButton RadioButton2;
        internal System.Windows.Forms.RadioButton RadioButton1;
        internal System.Windows.Forms.Label Label32;
        internal System.Windows.Forms.Panel Panel2;
        internal System.Windows.Forms.ComboBox ComboBox3;
        internal System.Windows.Forms.Label Label28;
        internal System.Windows.Forms.TextBox TextBox33;
        internal System.Windows.Forms.Label Label40;
        internal System.Windows.Forms.TextBox TextBox32;
        internal System.Windows.Forms.Label Label39;
        internal System.Windows.Forms.TextBox TextBox31;
        internal System.Windows.Forms.Label Label38;
        internal System.Windows.Forms.TabPage TabPage4;
        internal System.Windows.Forms.TabControl TabControl3;
        internal System.Windows.Forms.TabPage TabPage8;
        internal System.Windows.Forms.Button Button4;
        internal System.Windows.Forms.ComboBox ComboBox4;
        internal System.Windows.Forms.OpenFileDialog ofd1;
        internal System.Windows.Forms.Button Button7;
        internal System.Windows.Forms.Button BtnAntecedentesCriminais;
        internal System.Windows.Forms.TextBox TxtAntecedentesCriminais;
        internal System.Windows.Forms.Label Label81;
        internal System.Windows.Forms.TextBox TextBox60;
        internal System.Windows.Forms.TabPage TabPage13;
        internal System.Windows.Forms.Label Label80;
        internal System.Windows.Forms.TextBox TextBox59;
        internal System.Windows.Forms.Label Label79;
        internal System.Windows.Forms.TextBox TextBox58;
        internal System.Windows.Forms.Label Label78;
        internal System.Windows.Forms.TextBox TextBox57;
        internal System.Windows.Forms.Label Label77;
        internal System.Windows.Forms.TextBox TextBox56;
        internal System.Windows.Forms.Label Label76;
        internal System.Windows.Forms.TextBox TextBox55;
        internal System.Windows.Forms.Label Label75;
        internal System.Windows.Forms.TextBox TextBox54;
        internal System.Windows.Forms.Label Label74;
        internal System.Windows.Forms.TextBox TextBox53;
        internal System.Windows.Forms.Label Label73;
        internal System.Windows.Forms.TextBox TextBox52;
        internal System.Windows.Forms.Label Label72;
        internal System.Windows.Forms.ComboBox ComboBox1;
        internal System.Windows.Forms.Label Label71;
        internal System.Windows.Forms.TextBox TextBox51;
        internal System.Windows.Forms.Label Label70;
        internal System.Windows.Forms.TextBox TextBox50;
        internal System.Windows.Forms.Label Label69;
        internal System.Windows.Forms.TextBox TextBox36;
        internal System.Windows.Forms.Label Label19;
        internal System.Windows.Forms.TextBox TextBox19;
        internal System.Windows.Forms.Label Label20;
        internal System.Windows.Forms.TextBox txtEmail;
        internal System.Windows.Forms.Label Label15;
        internal System.Windows.Forms.Label Label11;
        internal System.Windows.Forms.Label Label13;
        internal System.Windows.Forms.Label Label12;
        internal System.Windows.Forms.Label Label10;
        internal System.Windows.Forms.TextBox txtResidencia;
        internal System.Windows.Forms.Label Label17;
        internal System.Windows.Forms.Label Label18;
        internal System.Windows.Forms.Label Label9;
        internal System.Windows.Forms.Label Label8;
        internal System.Windows.Forms.TextBox txtDomicilio;
        internal System.Windows.Forms.TextBox txtNacionalidade;
        internal System.Windows.Forms.Label Label6;
        internal System.Windows.Forms.Label Label16;
        internal System.Windows.Forms.Label Label21;
        internal System.Windows.Forms.TextBox TextBox21;
        internal System.Windows.Forms.Label Label22;
        internal System.Windows.Forms.Label Label7;
        internal System.Windows.Forms.Panel Panel1;
        internal System.Windows.Forms.Label Label43;
        internal System.Windows.Forms.TextBox TextBox35;
        internal System.Windows.Forms.Label Label42;
        internal System.Windows.Forms.TextBox TextBox34;
        internal System.Windows.Forms.Label Label41;
        internal System.Windows.Forms.DataGridView DataGridView2;
        internal System.Windows.Forms.Label Label5;
        internal System.Windows.Forms.TextBox TextBox13;
        internal System.Windows.Forms.TabPage TabPage2;
        internal System.Windows.Forms.Label Label14;
        internal System.Windows.Forms.TextBox TextBox22;
        internal System.Windows.Forms.Label Label23;
        internal System.Windows.Forms.Label Label24;
        internal System.Windows.Forms.TextBox TextBox24;
        internal System.Windows.Forms.Label Label25;
        internal System.Windows.Forms.Label Label26;
        internal System.Windows.Forms.TextBox TextBox26;
        internal System.Windows.Forms.Label Label27;
        internal System.Windows.Forms.TextBox txtRG;
        internal System.Windows.Forms.Label Label4;
        internal System.Windows.Forms.Label Label3;
        internal System.Windows.Forms.TextBox txtnome;
        internal System.Windows.Forms.Label Label2;
        internal System.Windows.Forms.TabPage TabPage1;
        internal System.Windows.Forms.TabControl TabControl1;
        internal System.Windows.Forms.TabPage TabPage3;
        internal System.Windows.Forms.TabControl TabControl2;
        internal System.Windows.Forms.TabPage TabPage5;
        internal System.Windows.Forms.Button Button10;
        internal System.Windows.Forms.ComboBox ComboBox2;
        internal System.Windows.Forms.TabPage TabPage6;
        internal System.Windows.Forms.Button Button9;
        internal System.Windows.Forms.Button Button6;
        internal System.Windows.Forms.Button Button5;
        internal System.Windows.Forms.TextBox TextBox30;
        internal System.Windows.Forms.Label Label36;
        internal System.Windows.Forms.TextBox TextBox29;
        internal System.Windows.Forms.Label Label35;
        internal System.Windows.Forms.TextBox TextBox28;
        internal System.Windows.Forms.Label Label34;
        internal System.Windows.Forms.TextBox TextBox27;
        internal System.Windows.Forms.Label Label33;
        internal System.Windows.Forms.DataGridView DataGridView1;
        internal System.Windows.Forms.TabPage TabPage7;
        internal System.Windows.Forms.Label Label37;
        private System.Windows.Forms.ComboBox cmbSexo;
        private System.Windows.Forms.Label label29;
        internal System.Windows.Forms.Button button14;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox62;
        private System.Windows.Forms.TextBox textBox61;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnSalvar;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.MaskedTextBox mktCPF;
        private System.Windows.Forms.MaskedTextBox mktCepResidencia;
        private System.Windows.Forms.MaskedTextBox mktCepDomicilio;
        private System.Windows.Forms.MaskedTextBox mktCelular;
        private System.Windows.Forms.MaskedTextBox mktTelefone;
        private System.Windows.Forms.DateTimePicker dtpDataNascimento;
        private System.Windows.Forms.ComboBox cmbEstadoCivil;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.MaskedTextBox maskedTextBox6;
        private System.Windows.Forms.MaskedTextBox maskedTextBox7;
        private System.Windows.Forms.MaskedTextBox maskedTextBox8;
        private System.Windows.Forms.MaskedTextBox maskedTextBox9;
        private System.Windows.Forms.MaskedTextBox maskedTextBox10;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private System.Windows.Forms.ComboBox comboBox7;
        private System.Windows.Forms.ComboBox comboBox8;
    }
}