﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Negocio
{
    public class DadoBancario
    {
        public int id { get; set; }
        public string banco { get; set; }
        public string Agencia { get; set; }
        public string TipoConta { get; set; }
        public string numero { get; set; }
    }
}
