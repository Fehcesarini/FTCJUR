﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Negocio
{
    public class Previdenciario
    {
        public int id { get; set;  }
        public string carteiraTrabalho { get; set; }
        public string CNIS { get; set; }
        public string benificio { get; set; }
        public string aposentadoria { get; set; }
        public string procedimentoADM { get; set; }
        public string obs { get; set; }
        
    }
}
