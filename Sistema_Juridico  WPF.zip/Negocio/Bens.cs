﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Negocio
{
    public class Bens
    {
        public int id { get; set; }
        public string tipoImovel { get; set; }
        public string descricaodoben { get; set; }
        public string valorBens { get; set; }
        public string obs { get; set; }
        public string delete { get; set; }
    }
}
