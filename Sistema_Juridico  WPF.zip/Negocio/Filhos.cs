﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Negocio
{
  public class Filhos
    {
        public int id { get; set; }
        public string nome { get; set; }
        public string cpf { get; set; }
        public string rg { get; set; }
        public DateTime dtnascimento { get; set; }
        public string sexo { get; set; }
        public string obs { get; set; }
        public string delete { get; set; }

    }
}
