﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Negocio
{
  public  class SerialKey
    {
        public string id { get; set; }
        public string idEmpresa { get; set; }
        public string cnpjCPF { get; set; }
        public string RazaoSocial { get; set; }
        public string serialkey { get; set; }
        public string macadress { get; set; }
    }
}
