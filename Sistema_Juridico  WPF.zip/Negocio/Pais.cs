﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Negocio
{
    public class Pais
    {
        public int pais_id { get; set; }
        public string pais_descricao { get; set; }
        public string pais_sigla { get; set; }
    }
}
